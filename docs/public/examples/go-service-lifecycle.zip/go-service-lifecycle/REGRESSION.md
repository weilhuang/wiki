# 响应合同与停机证据的反例回归

本修订补上了旧断言中的四种假通过。测试套件运行成功只说明实际编写的断言通过，并不自动证明正文承诺的全部行为；必须让明确破坏合同的实现失败。

| 命名错误实现 | 错误改动 | 旧断言 | 本修订要求 |
| --- | --- | --- | --- |
| empty-response | 序列化后把所有响应替换为 `{}` | 全套测试错误通过 | HTTP 每行的准确 wire body，以及真实 main 的 lab-order 响应断言失败 |
| wrong-content-type | 把响应媒体类型换成 text/plain | 全套测试错误通过 | HTTP 解析后的媒体类型/charset，以及 main 响应头断言失败 |
| truncated-response | 声明 Content-Length 999，实际只发送原 body | 正常 main 测试错误通过 | 完整读取必须无错误；unexpected EOF 立即失败 |
| startup-skip-pool-join | 占用端口的启动失败分支跳过池取消与等待 | 启动失败测试错误通过 | 实际 Pool.Done 未关闭，不能生成完成证据或关闭依赖；顺序断言失败 |

每个变体都在独立副本中编译并运行，不修改正确实验项目。旧版相应测试 exit 0 的假通过与本修订相应测试 exit 1 的正确拒绝均实际复现。失败必须由上述断言报告，不能把编译错误、无关 panic 或测试超时算成检出。

## 精确断言的组成

- 每个输入行独立写出完整成功/公开错误 JSON，不从响应反推 expected，也不复用生产 Result 再编码
- 成功 ID 来自业务替身的不同返回值；商品、数量及边界样本不同，防止常量实现蒙混通过
- 显式拒绝空商品、全空白商品、数量 0/负数/超过 100；数量 1 与 100 是成功边界
- 响应体必须完整读取；额外字段、额外 JSON、错误 ID、丢失字段及错误公开 error 均与期望不同
- 正常 main 检查完整响应与媒体类型；强制路径检查该受控无响应头请求的连接中断，不能接受成功或客户端 watchdog 超时
- startup、graceful、forced 都要求真实池完成在依赖关闭以前；后两者还要求 handler/job 先退出，再发生 pool_done

## 手工复核

只在一次性副本里应用上述一项改动，构建 `cmd/shutdownlab`，设置 `LIFECYCLE_BINARY`，然后运行相关用例。前两项可用全套普通测试；截断用 `go test -run '^TestRealMainSignalLifecycle$/^graceful$' ./lifecycle`；跳过启动池清理用 `go test -run '^TestRealMainStartupFailureCleansOwnedPool$' ./lifecycle`。每次恢复正确源文件后再跑完整 `verify.sh`。

这种反例覆盖不声称穷举所有程序错误，也不扩大到 TLS、HTTP/2、数据库持久化或集群环境。
