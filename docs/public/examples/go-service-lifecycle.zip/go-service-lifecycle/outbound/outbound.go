package outbound

import (
	"context"
	"errors"
	"fmt"
	"io"
	"math/rand/v2"
	"net"
	"net/http"
	"time"
)

var ErrResponseTooLarge = errors.New("response exceeds limit")

type StatusError struct{ Status int }

func (e *StatusError) Error() string { return fmt.Sprintf("downstream status %d", e.Status) }

// NewClient owns a reusable Transport. Configure it before sharing it.
func NewClient() *http.Client {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.DialContext = (&net.Dialer{Timeout: 500 * time.Millisecond, KeepAlive: 30 * time.Second}).DialContext
	tr.TLSHandshakeTimeout = time.Second
	tr.ResponseHeaderTimeout = 800 * time.Millisecond
	tr.MaxConnsPerHost = 8
	tr.MaxIdleConns = 32
	tr.MaxIdleConnsPerHost = 8
	tr.IdleConnTimeout = 30 * time.Second
	return &http.Client{Transport: tr, Timeout: 2 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
}

type Getter struct {
	Client         *http.Client
	Attempts       int
	AttemptTimeout time.Duration
	MaxBody        int64
	Delay          func(failedAttempt int) time.Duration
}

func (g Getter) Get(ctx context.Context, url string) ([]byte, error) {
	if g.Client == nil || g.Attempts < 1 || g.AttemptTimeout <= 0 || g.MaxBody < 1 || g.MaxBody > 1<<30 {
		return nil, errors.New("invalid getter configuration")
	}
	if _, ok := ctx.Deadline(); !ok {
		return nil, errors.New("logical call requires deadline")
	}
	delay := g.Delay
	if delay == nil {
		delay = func(attempt int) time.Duration {
			cap := 25 * time.Millisecond * time.Duration(1<<min(attempt-1, 5))
			return time.Duration(rand.Int64N(int64(cap) + 1))
		}
	}
	for attempt := 1; attempt <= g.Attempts; attempt++ {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		data, err := g.once(ctx, url)
		if err == nil {
			return data, nil
		}
		var status *StatusError
		retry := errors.As(err, &status) && (status.Status == 502 || status.Status == 503 || status.Status == 504)
		if !retry || attempt == g.Attempts {
			return nil, err
		}
		timer := time.NewTimer(max(0, delay(attempt)))
		select {
		case <-ctx.Done():
			timer.Stop()
			return nil, ctx.Err()
		case <-timer.C:
		}
	}
	panic("unreachable")
}
func (g Getter) once(parent context.Context, url string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(parent, g.AttemptTimeout)
	defer cancel() // Body is consumed/closed before this cancellation.
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	response, err := g.Client.Do(req)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	data, err := io.ReadAll(io.LimitReader(response.Body, g.MaxBody+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > g.MaxBody {
		return nil, ErrResponseTooLarge
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return nil, &StatusError{Status: response.StatusCode}
	}
	return data, nil
}
