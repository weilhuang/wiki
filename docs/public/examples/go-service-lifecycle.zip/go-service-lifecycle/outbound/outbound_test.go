package outbound

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"net/http/httptrace"
	"strings"
	"sync/atomic"
	"testing"
	"testing/synctest"
	"time"
)

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func testGetter(client *http.Client) Getter {
	return Getter{Client: client, Attempts: 3, AttemptTimeout: time.Second, MaxBody: 32, Delay: func(int) time.Duration { return 0 }}
}
func budget(t *testing.T) context.Context {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	t.Cleanup(cancel)
	return ctx
}

func TestRetryStatusCeiling(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		w.WriteHeader(503)
		_, _ = io.WriteString(w, "busy")
	}))
	defer server.Close()
	_, err := testGetter(server.Client()).Get(budget(t), server.URL)
	var status *StatusError
	if !errors.As(err, &status) || status.Status != 503 || calls.Load() != 3 {
		t.Fatalf("err=%v calls=%d", err, calls.Load())
	}
}
func TestHTTP1ConnectionReuseAfterEOF(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { _, _ = io.WriteString(w, "ok") }))
	defer server.Close()
	client := NewClient()
	defer client.CloseIdleConnections()
	g := testGetter(client)
	var connections []bool
	ctx := httptrace.WithClientTrace(budget(t), &httptrace.ClientTrace{GotConn: func(info httptrace.GotConnInfo) { connections = append(connections, info.Reused) }})
	for range 2 {
		data, err := g.Get(ctx, server.URL)
		if err != nil || string(data) != "ok" {
			t.Fatalf("data=%q err=%v", data, err)
		}
	}
	if len(connections) != 2 || connections[0] || !connections[1] {
		t.Fatalf("GotConn.Reused=%v", connections)
	}
}
func TestOversizeResponseDoesNotRetry(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		_, _ = io.WriteString(w, strings.Repeat("x", 100))
	}))
	defer server.Close()
	_, err := testGetter(server.Client()).Get(budget(t), server.URL)
	if !errors.Is(err, ErrResponseTooLarge) || calls.Load() != 1 {
		t.Fatalf("err=%v calls=%d", err, calls.Load())
	}
}
func TestBodyTruncationDoesNotRetry(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		w.Header().Set("Content-Length", "10")
		_, _ = io.WriteString(w, "short")
	}))
	defer server.Close()
	_, err := testGetter(server.Client()).Get(budget(t), server.URL)
	if !errors.Is(err, io.ErrUnexpectedEOF) || calls.Load() != 1 {
		t.Fatalf("err=%v calls=%d", err, calls.Load())
	}
}
func TestNoHeaderCancellation(t *testing.T) {
	entered := make(chan struct{})
	exited := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer close(exited)
		close(entered)
		<-r.Context().Done()
	}))
	defer server.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	done := make(chan error, 1)
	go func() { _, err := testGetter(server.Client()).Get(ctx, server.URL); done <- err }()
	<-entered
	cancel()
	if err := <-done; !errors.Is(err, context.Canceled) {
		t.Fatalf("err=%v", err)
	}
	<-exited
}
func TestBudgetIncludesBackoff(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		calls := 0
		client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
			calls++
			return &http.Response{StatusCode: 503, Body: io.NopCloser(strings.NewReader("busy")), Header: make(http.Header), Request: r}, nil
		})}
		g := testGetter(client)
		g.Delay = func(int) time.Duration { return 2 * time.Second }
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		started := time.Now()
		_, err := g.Get(ctx, "http://example.test")
		if !errors.Is(err, context.DeadlineExceeded) || calls != 1 || time.Since(started) != time.Second {
			t.Fatalf("err=%v calls=%d elapsed=%v", err, calls, time.Since(started))
		}
	})
}
func TestAttemptDeadline(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		calls := 0
		client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
			calls++
			<-r.Context().Done()
			return nil, r.Context().Err()
		})}
		g := testGetter(client)
		g.AttemptTimeout = 20 * time.Millisecond
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		started := time.Now()
		_, err := g.Get(ctx, "http://example.test")
		if !errors.Is(err, context.DeadlineExceeded) || calls != 1 || time.Since(started) != 20*time.Millisecond {
			t.Fatalf("err=%v calls=%d elapsed=%v", err, calls, time.Since(started))
		}
	})
}
func TestPOSTUnknownResult(t *testing.T) {
	var effects atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.Copy(io.Discard, r.Body)
		effects.Add(1)
		conn, _, err := w.(http.Hijacker).Hijack()
		if err != nil {
			panic(err)
		}
		_ = conn.Close()
	}))
	defer server.Close()
	client := NewClient()
	defer client.CloseIdleConnections()
	post := func() {
		req, _ := http.NewRequestWithContext(budget(t), http.MethodPost, server.URL, strings.NewReader(`{"item":"book"}`))
		response, err := client.Do(req)
		if response != nil {
			response.Body.Close()
		}
		if err == nil {
			t.Fatal("expected unknown response")
		}
	}
	post()
	if effects.Load() != 1 {
		t.Fatalf("effects=%d", effects.Load())
	}
	// Negative control: a user-level blind replay duplicates the business action.
	post()
	if effects.Load() != 2 {
		t.Fatalf("effects=%d", effects.Load())
	}
}
