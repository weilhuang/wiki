package lifecycle

import (
	"context"
	"errors"
	"sync"
)

type HTTPServer interface {
	Shutdown(context.Context) error
	Close() error
}
type Jobs interface {
	CloseAdmission()
	Cancel()
	Wait(context.Context) error
}
type Stopper struct {
	HTTP           HTTPServer
	Jobs           Jobs
	Unready        func()
	StopProducers  func()
	WaitHandlers   func(context.Context) error
	CloseResources func() error
	once           sync.Once
	result         error
}

// Stop accepts two independent absolute deadlines: drain and final cleanup.
// It is idempotent. Concurrent calls wait for the first caller's result/deadlines.
func (s *Stopper) Stop(drain, final context.Context) error {
	s.once.Do(func() {
		if s.Unready != nil {
			s.Unready()
		}
		if s.StopProducers != nil {
			s.StopProducers()
		}
		httpErr := s.HTTP.Shutdown(drain)
		if httpErr != nil {
			httpErr = errors.Join(httpErr, s.HTTP.Close())
		}
		var handlerErr error
		if s.WaitHandlers != nil {
			handlerErr = s.WaitHandlers(final)
		}
		// HTTP handlers may submit work while draining, so close admission afterwards.
		s.Jobs.CloseAdmission()
		jobsErr := s.Jobs.Wait(drain)
		if jobsErr != nil {
			s.Jobs.Cancel()
			jobsErr = errors.Join(jobsErr, s.Jobs.Wait(final))
		}
		s.result = errors.Join(httpErr, handlerErr, jobsErr)
		// Do not close dependencies underneath a still-running owned task.
		if err := s.Jobs.Wait(final); err != nil {
			s.result = errors.Join(s.result, err)
			return
		}
		if handlerErr != nil {
			return
		}
		if s.CloseResources != nil {
			s.result = errors.Join(s.result, s.CloseResources())
		}
	})
	return s.result
}
