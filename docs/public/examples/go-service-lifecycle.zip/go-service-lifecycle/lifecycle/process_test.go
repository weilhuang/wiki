//go:build unix

package lifecycle

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"syscall"
	"testing"
	"time"
)

type child struct {
	cmd      *exec.Cmd
	input    io.WriteCloser
	events   chan map[string]string
	finished chan error
	seen     []string
}

func startChild(t *testing.T, args ...string) *child {
	t.Helper()
	binary := os.Getenv("LIFECYCLE_BINARY")
	if binary == "" {
		t.Skip("real main requires verify.sh / LIFECYCLE_BINARY")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	t.Cleanup(cancel)
	c := &child{cmd: exec.CommandContext(ctx, binary, args...), events: make(chan map[string]string, 64), finished: make(chan error, 1)}
	var err error
	c.input, err = c.cmd.StdinPipe()
	if err != nil {
		t.Fatal(err)
	}
	out, err := c.cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	c.cmd.Stderr = os.Stderr
	if err = c.cmd.Start(); err != nil {
		t.Fatal(err)
	}
	scanned := make(chan struct{})
	go func() {
		defer close(scanned)
		defer close(c.events)
		s := bufio.NewScanner(out)
		for s.Scan() {
			var event map[string]string
			if json.Unmarshal(s.Bytes(), &event) == nil {
				c.events <- event
			}
		}
	}()
	go func() { <-scanned; c.finished <- c.cmd.Wait() }()
	t.Cleanup(func() { _ = c.input.Close(); _ = c.cmd.Process.Kill() })
	return c
}
func (c *child) until(t *testing.T, name string) map[string]string {
	t.Helper()
	deadline := time.NewTimer(8 * time.Second)
	defer deadline.Stop()
	for {
		select {
		case event, ok := <-c.events:
			if !ok {
				t.Fatalf("events ended before %s; got %v", name, c.seen)
			}
			c.seen = append(c.seen, event["event"])
			if event["event"] == name {
				return event
			}
		case <-deadline.C:
			t.Fatalf("event timeout: %s", name)
		}
	}
}
func TestRealMainSignalLifecycle(t *testing.T) {
	for _, forced := range []bool{false, true} {
		name := "graceful"
		grace := "3s"
		if forced {
			name = "forced"
			grace = "50ms"
		}
		t.Run(name, func(t *testing.T) {
			c := startChild(t, "-grace", grace)
			address := c.until(t, "ready")["address"]
			responseDone := make(chan *http.Response, 1)
			requestErr := make(chan error, 1)
			client := &http.Client{Timeout: 5 * time.Second, Transport: &http.Transport{DisableKeepAlives: true}}
			defer client.CloseIdleConnections()
			go func() {
				req, _ := http.NewRequest("POST", "http://"+address+"/orders", strings.NewReader(`{"item":"book","count":1}`))
				req.Header.Set("Content-Type", "application/json")
				r, err := client.Do(req)
				responseDone <- r
				requestErr <- err
			}()
			// Both request and background work must exist before the real signal.
			started := map[string]bool{}
			for !started["handler_started"] || !started["job_started"] {
				select {
				case e, ok := <-c.events:
					if !ok {
						t.Fatal("process events ended before work started")
					}
					started[e["event"]] = true
					c.seen = append(c.seen, e["event"])
				case <-time.After(5 * time.Second):
					t.Fatal("work did not start")
				}
			}
			if err := c.cmd.Process.Signal(syscall.SIGTERM); err != nil {
				t.Fatal(err)
			}
			c.until(t, "listener_closed")
			conn, err := net.DialTimeout("tcp", address, time.Second)
			if err == nil {
				conn.Close()
				t.Fatal("listener still accepts new connections")
			}
			if !forced {
				_, _ = io.WriteString(c.input, "release-http\n")
				r := <-responseDone
				if err := <-requestErr; err != nil {
					t.Fatal(err)
				}
				if r.StatusCode != 201 {
					t.Fatalf("status=%d", r.StatusCode)
				}
				body, readErr := io.ReadAll(r.Body)
				closeErr := r.Body.Close()
				if readErr != nil || closeErr != nil {
					t.Fatalf("graceful body incomplete: read=%v close=%v bytes=%q", readErr, closeErr, body)
				}
				if string(body) != "{\"id\":\"lab-order\"}\n" {
					t.Fatalf("graceful body=%q want complete lab-order DTO", body)
				}
				if r.Header.Get("Content-Type") != "application/json; charset=utf-8" {
					t.Fatalf("graceful Content-Type=%q", r.Header.Get("Content-Type"))
				}
				select {
				case err := <-c.finished:
					t.Fatalf("process left background work: %v", err)
				default:
				}
				_, _ = io.WriteString(c.input, "release-job\n")
			} else {
				r := <-responseDone
				requestFailure := <-requestErr
				if r != nil {
					r.Body.Close()
				}
				// This handler sends no header before cancellation. Server.Close must
				// abort its connection; a 201 or the client's own timeout is not success.
				if requestFailure == nil || r != nil {
					t.Fatalf("forced request should be interrupted: response=%v error=%v", r, requestFailure)
				}
				if errors.Is(requestFailure, context.DeadlineExceeded) {
					t.Fatalf("forced interruption only happened at client watchdog: %v", requestFailure)
				}
			}
			final := c.until(t, "stopped")
			err = <-c.finished
			if forced {
				var exit *exec.ExitError
				if !errors.As(err, &exit) || exit.ExitCode() != 1 || final["result"] != "forced" {
					t.Fatalf("exit=%v event=%v", err, final)
				}
			} else if err != nil || final["result"] != "graceful" {
				t.Fatalf("exit=%v event=%v", err, final)
			}
			counts := map[string]int{}
			for _, event := range c.seen {
				counts[event]++
			}
			for _, event := range []string{"handler_exited", "job_exited", "pool_done", "resource_closed"} {
				if counts[event] != 1 {
					t.Fatalf("%s count=%d events=%v", event, counts[event], c.seen)
				}
			}
			assertBefore(t, c.seen, "handler_exited", "pool_done")
			assertBefore(t, c.seen, "job_exited", "pool_done")
			assertBefore(t, c.seen, "pool_done", "resource_closed")
			assertBefore(t, c.seen, "resource_closed", "stopped")
		})
	}
}
func TestRealMainStartupFailureCleansOwnedPool(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	c := startChild(t, "-listen", listener.Addr().String())
	c.until(t, "startup_failed")
	err = <-c.finished
	var exit *exec.ExitError
	if !errors.As(err, &exit) || exit.ExitCode() != 2 {
		t.Fatalf("exit=%v", err)
	}
	for _, name := range []string{"pool_done", "resource_closed", "startup_failed"} {
		count := 0
		for _, event := range c.seen {
			if event == name {
				count++
			}
		}
		if count != 1 {
			t.Fatalf("startup %s count=%d events=%v", name, count, c.seen)
		}
	}
	assertBefore(t, c.seen, "pool_done", "resource_closed")
	assertBefore(t, c.seen, "resource_closed", "startup_failed")
}

func assertBefore(t *testing.T, events []string, first, second string) {
	t.Helper()
	a, b := -1, -1
	for i, name := range events {
		if name == first {
			a = i
		}
		if name == second {
			b = i
		}
	}
	if a < 0 || b < 0 || a >= b {
		t.Fatalf("expected %s before %s; events=%v", first, second, events)
	}
}
