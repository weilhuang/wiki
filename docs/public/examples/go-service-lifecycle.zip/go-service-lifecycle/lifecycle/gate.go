package lifecycle

import (
	"context"
	"net/http"
	"sync"
)

// Gate owns the admission and completion of handlers that use application resources.
type Gate struct {
	mu     sync.Mutex
	sealed bool
	active int
	done   chan struct{}
}

func NewGate() *Gate { return &Gate{done: make(chan struct{})} }
func (g *Gate) Wrap(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		g.mu.Lock()
		if g.sealed {
			g.mu.Unlock()
			http.Error(w, "draining", 503)
			return
		}
		g.active++
		g.mu.Unlock()
		defer func() {
			g.mu.Lock()
			defer g.mu.Unlock()
			g.active--
			if g.sealed && g.active == 0 {
				close(g.done)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
func (g *Gate) Seal() {
	g.mu.Lock()
	defer g.mu.Unlock()
	if !g.sealed {
		g.sealed = true
		if g.active == 0 {
			close(g.done)
		}
	}
}
func (g *Gate) Wait(ctx context.Context) error {
	select {
	case <-g.done:
		return nil
	default:
	}
	select {
	case <-g.done:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}
