package lifecycle

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"
	"testing/synctest"
	"time"

	"example.com/lifecyclelab/workers"
)

type serverFake struct {
	events  *[]string
	failure error
}

func (s serverFake) Shutdown(context.Context) error {
	*s.events = append(*s.events, "http drain")
	return s.failure
}
func (s serverFake) Close() error { *s.events = append(*s.events, "http force"); return nil }

type jobsFake struct{ events *[]string }

func (j jobsFake) CloseAdmission()            { *j.events = append(*j.events, "jobs admission close") }
func (j jobsFake) Cancel()                    { *j.events = append(*j.events, "jobs cancel") }
func (j jobsFake) Wait(context.Context) error { *j.events = append(*j.events, "jobs join"); return nil }
func TestStopOrderAndExactlyOnce(t *testing.T) {
	var events []string
	stop := &Stopper{HTTP: serverFake{events: &events}, Jobs: jobsFake{&events}, Unready: func() { events = append(events, "unready") }, StopProducers: func() { events = append(events, "producers stop") }, CloseResources: func() error { events = append(events, "resources close"); return nil }}
	for range 2 {
		if err := stop.Stop(context.Background(), context.Background()); err != nil {
			t.Fatal(err)
		}
	}
	want := []string{"unready", "producers stop", "http drain", "jobs admission close", "jobs join", "jobs join", "resources close"}
	if !reflect.DeepEqual(events, want) {
		t.Fatalf("events=%v", events)
	}
}
func TestShutdownDoesNotJoinDetachedWork(t *testing.T) {
	release := make(chan struct{})
	exited := make(chan struct{})
	started := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		go func() { defer close(exited); close(started); <-release }()
		w.WriteHeader(202)
	}))
	defer server.Close()
	response, err := server.Client().Get(server.URL)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	<-started
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := server.Config.Shutdown(ctx); err != nil {
		t.Fatal(err)
	}
	select {
	case <-exited:
		t.Fatal("detached work exited unexpectedly")
	default:
	}
	close(release)
	<-exited
}
func TestDrainDeadlineCancelsThenJoins(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := workers.New(1, 1)
		started := make(chan struct{})
		exited := make(chan struct{})
		_, err := p.Submit(func(ctx context.Context) error { defer close(exited); close(started); <-ctx.Done(); return ctx.Err() })
		if err != nil {
			t.Fatal(err)
		}
		<-started
		var events []string
		closed := 0
		stop := &Stopper{HTTP: serverFake{events: &events}, Jobs: p, CloseResources: func() error {
			select {
			case <-exited:
			default:
				t.Error("resource closed before worker exit")
			}
			closed++
			return nil
		}}
		drain, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		final, cancelFinal := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancelFinal()
		if err := stop.Stop(drain, final); !errors.Is(err, context.DeadlineExceeded) {
			t.Fatalf("err=%v", err)
		}
		if closed != 1 {
			t.Fatalf("closed=%d", closed)
		}
	})
}

func TestUncooperativeTaskDoesNotLoseResourceOwnership(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := workers.New(1, 1)
		started := make(chan struct{})
		release := make(chan struct{})
		_, err := p.Submit(func(context.Context) error { close(started); <-release; return nil })
		if err != nil {
			t.Fatal(err)
		}
		<-started
		var events []string
		closed := false
		stop := &Stopper{HTTP: serverFake{events: &events}, Jobs: p, CloseResources: func() error { closed = true; return nil }}
		drain, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		final, cancelFinal := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancelFinal()
		if err := stop.Stop(drain, final); !errors.Is(err, context.DeadlineExceeded) {
			t.Fatalf("err=%v", err)
		}
		if closed {
			t.Fatal("closed resources under active task")
		}
		close(release)
		if err := p.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
	})
}

func TestGateSealsAdmissionAndJoinsHandlers(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		gate := NewGate()
		entered := make(chan struct{})
		release := make(chan struct{})
		handler := gate.Wrap(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { close(entered); <-release; w.WriteHeader(204) }))
		firstDone := make(chan struct{})
		go func() {
			defer close(firstDone)
			handler.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", "/", nil))
		}()
		<-entered
		gate.Seal()
		gate.Seal()
		recorder := httptest.NewRecorder()
		handler.ServeHTTP(recorder, httptest.NewRequest("GET", "/", nil))
		if recorder.Code != 503 {
			t.Fatalf("status=%d", recorder.Code)
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if err := gate.Wait(ctx); !errors.Is(err, context.DeadlineExceeded) {
			t.Fatalf("err=%v", err)
		}
		close(release)
		if err := gate.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
		<-firstDone
	})
}
