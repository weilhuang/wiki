package pipeline

import (
	"context"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestHTTPContract(t *testing.T) {
	// The expected wire bodies are independent literals, not production Result DTOs.
	tests := []struct {
		name, method, path, media, body string
		status                          int
		failure, returnID, wantBody     string
		wantOrders                      []Order
	}{
		{"valid", "POST", "/orders", "application/json; charset=utf-8", `{"item":" book ","count":2}`, 201, "", "order-1", "{\"id\":\"order-1\"}\n", []Order{{"book", 2}}},
		{"different_values", "POST", "/orders", "application/json", `{"item":" notebook ","count":7}`, 201, "", "returned-by-service-7", "{\"id\":\"returned-by-service-7\"}\n", []Order{{"notebook", 7}}},
		{"unicode_upper_bound", "POST", "/orders", "application/json", `{"item":"  钢笔  ","count":100}`, 201, "", "order-unicode", "{\"id\":\"order-unicode\"}\n", []Order{{"钢笔", 100}}},
		{"lower_bound", "POST", "/orders", "application/json", `{"item":"eraser","count":1}`, 201, "", "order-small", "{\"id\":\"order-small\"}\n", []Order{{"eraser", 1}}},
		{"path", "POST", "/missing", "application/json", `{}`, 404, "", "", "{\"error\":\"not_found\"}\n", nil},
		{"method", "GET", "/orders", "application/json", `{}`, 405, "", "", "{\"error\":\"method_not_allowed\"}\n", nil},
		{"media", "POST", "/orders", "text/plain", `{}`, 415, "", "", "{\"error\":\"unsupported_media_type\"}\n", nil},
		{"empty", "POST", "/orders", "application/json", ``, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"malformed", "POST", "/orders", "application/json", `{"item":`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"unknown", "POST", "/orders", "application/json", `{"item":"book","count":2,"admin":true}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"trailing", "POST", "/orders", "application/json", `{"item":"book","count":2} {}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"null", "POST", "/orders", "application/json", `null`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"range", "POST", "/orders", "application/json", `{"item":"book","count":101}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"zero_count", "POST", "/orders", "application/json", `{"item":"book","count":0}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"negative_count", "POST", "/orders", "application/json", `{"item":"book","count":-1}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"empty_item", "POST", "/orders", "application/json", `{"item":"","count":1}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"blank_item", "POST", "/orders", "application/json", `{"item":"  ","count":1}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"wrong_field_type", "POST", "/orders", "application/json", `{"item":"book","count":"2"}`, 400, "", "", "{\"error\":\"invalid_order\"}\n", nil},
		{"oversize", "POST", "/orders", "application/json", `{"item":"` + strings.Repeat("x", MaxBody) + `","count":2}`, 413, "", "", "{\"error\":\"body_too_large\"}\n", nil},
		{"conflict", "POST", "/orders", "application/json", `{"item":"book","count":2}`, 409, "conflict", "", "{\"error\":\"order_conflict\"}\n", []Order{{"book", 2}}},
		{"unavailable", "POST", "/orders", "application/json", `{"item":"book","count":2}`, 503, "unavailable", "", "{\"error\":\"unavailable\"}\n", []Order{{"book", 2}}},
		{"deadline", "POST", "/orders", "application/json", `{"item":"book","count":2}`, 504, "deadline", "", "{\"error\":\"deadline_exceeded\"}\n", []Order{{"book", 2}}},
		{"private_error", "POST", "/orders", "application/json", `{"item":"book","count":2}`, 500, "private", "", "{\"error\":\"internal_error\"}\n", []Order{{"book", 2}}},
		{"panic", "POST", "/orders", "application/json", `{"item":"book","count":2}`, 500, "panic", "", "{\"error\":\"internal_error\"}\n", []Order{{"book", 2}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var mu sync.Mutex
			var orders []Order
			server := httptest.NewServer(API{Submit: func(_ context.Context, o Order) (string, error) {
				mu.Lock()
				orders = append(orders, o)
				mu.Unlock()
				switch tt.failure {
				case "conflict":
					return "", fmt.Errorf("private detail: %w", ErrConflict)
				case "unavailable":
					return "", ErrUnavailable
				case "deadline":
					return "", context.DeadlineExceeded
				case "private":
					return "", errors.New("private detail")
				case "panic":
					panic("private detail")
				}
				return tt.returnID, nil
			}})
			defer server.Close()
			client := server.Client()
			client.Timeout = 2 * time.Second
			req, err := http.NewRequest(tt.method, server.URL+tt.path, strings.NewReader(tt.body))
			if err != nil {
				t.Fatal(err)
			}
			req.Header.Set("Content-Type", tt.media)
			response, err := client.Do(req)
			if err != nil {
				t.Fatal(err)
			}
			data, readErr := io.ReadAll(response.Body)
			closeErr := response.Body.Close()
			if readErr != nil || closeErr != nil {
				t.Fatalf("body read=%v close=%v bytes=%q", readErr, closeErr, data)
			}
			if response.StatusCode != tt.status {
				t.Fatalf("status=%d want=%d body=%s", response.StatusCode, tt.status, data)
			}
			if string(data) != tt.wantBody {
				t.Fatalf("wire body=%q want=%q", data, tt.wantBody)
			}
			media, params, err := mime.ParseMediaType(response.Header.Get("Content-Type"))
			if err != nil || media != "application/json" || params["charset"] != "utf-8" {
				t.Fatalf("Content-Type=%q parse=%v", response.Header.Get("Content-Type"), err)
			}
			wantAllow := ""
			if tt.status == 405 {
				wantAllow = "POST"
			}
			if response.Header.Get("Allow") != wantAllow {
				t.Fatalf("Allow=%q want=%q", response.Header.Get("Allow"), wantAllow)
			}
			mu.Lock()
			gotOrders := append([]Order(nil), orders...)
			mu.Unlock()
			if !reflect.DeepEqual(gotOrders, tt.wantOrders) {
				t.Fatalf("business calls/arguments=%+v want=%+v", gotOrders, tt.wantOrders)
			}
		})
	}
}

func TestMiddlewareOrder(t *testing.T) {
	var events []string
	named := func(name string) Middleware {
		return func(next http.Handler) http.Handler {
			return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				events = append(events, name+" before")
				next.ServeHTTP(w, r)
				events = append(events, name+" after")
			})
		}
	}
	Chain(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { events = append(events, "handler") }), named("outer"), named("inner")).ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", "/", nil))
	want := []string{"outer before", "inner before", "handler", "inner after", "outer after"}
	if !reflect.DeepEqual(events, want) {
		t.Fatalf("events=%v", events)
	}
}

func TestCommittedResponseCannotBecome500(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		w.WriteHeader(200)
		_, _ = io.WriteString(w, "prefix:")
		w.(http.Flusher).Flush()
		w.WriteHeader(500)
		_, _ = io.WriteString(w, "failure")
	}))
	defer server.Close()
	response, err := server.Client().Get(server.URL)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil {
		t.Fatal(err)
	}
	if response.StatusCode != 200 || string(body) != "prefix:failure" {
		t.Fatalf("status=%d body=%q", response.StatusCode, body)
	}
}
