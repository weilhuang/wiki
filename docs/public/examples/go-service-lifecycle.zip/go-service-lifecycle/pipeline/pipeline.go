// Package pipeline keeps transport decisions outside business operations.
package pipeline

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"mime"
	"net/http"
	"strings"
)

var ErrUnavailable = errors.New("service unavailable")
var ErrConflict = errors.New("order conflict")

const MaxBody = 1024

type Order struct {
	Item  string `json:"item"`
	Count int    `json:"count"`
}
type Submit func(context.Context, Order) (string, error)
type Result struct {
	ID    string `json:"id,omitempty"`
	Error string `json:"error,omitempty"`
}
type API struct {
	Submit       Submit
	OnPanic      func(any)
	OnWriteError func(error)
}

func (a API) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, MaxBody)
	status, result := a.evaluate(r)
	// Result is deliberately a fixed JSON-safe DTO; marshal before committing headers.
	body, err := json.Marshal(result)
	if err != nil {
		status = 500
		body = []byte(`{"error":"internal_error"}`)
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if status == 405 {
		w.Header().Set("Allow", "POST")
	}
	w.WriteHeader(status)
	if _, err := w.Write(append(body, '\n')); err != nil && a.OnWriteError != nil {
		a.OnWriteError(err)
	}
}

func (a API) evaluate(r *http.Request) (status int, result Result) {
	defer func() {
		if value := recover(); value != nil {
			if a.OnPanic != nil {
				a.OnPanic(value)
			}
			status, result = 500, Result{Error: "internal_error"}
		}
	}()
	if r.URL.Path != "/orders" {
		return 404, Result{Error: "not_found"}
	}
	if r.Method != http.MethodPost {
		return 405, Result{Error: "method_not_allowed"}
	}
	media, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || media != "application/json" {
		return 415, Result{Error: "unsupported_media_type"}
	}
	order, err := decode(r.Body)
	if err != nil {
		var large *http.MaxBytesError
		if errors.As(err, &large) {
			return 413, Result{Error: "body_too_large"}
		}
		return 400, Result{Error: "invalid_order"}
	}
	id, err := a.Submit(r.Context(), order)
	switch {
	case err == nil:
		return 201, Result{ID: id}
	case errors.Is(err, ErrConflict):
		return 409, Result{Error: "order_conflict"}
	case errors.Is(err, ErrUnavailable):
		return 503, Result{Error: "unavailable"}
	case errors.Is(err, context.DeadlineExceeded):
		return 504, Result{Error: "deadline_exceeded"}
	default:
		return 500, Result{Error: "internal_error"}
	}
}

func decode(body io.Reader) (Order, error) {
	dec := json.NewDecoder(body)
	dec.DisallowUnknownFields()
	var order *Order
	if err := dec.Decode(&order); err != nil {
		return Order{}, err
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		if err == nil {
			err = errors.New("multiple JSON values")
		}
		return Order{}, err
	}
	if order == nil || strings.TrimSpace(order.Item) == "" || order.Count < 1 || order.Count > 100 {
		return Order{}, errors.New("invalid order")
	}
	order.Item = strings.TrimSpace(order.Item)
	return *order, nil
}

// Middleware returns a new handler. Its pre/post behavior is explicit in the test.
type Middleware func(http.Handler) http.Handler

func Chain(handler http.Handler, middleware ...Middleware) http.Handler {
	for i := len(middleware) - 1; i >= 0; i-- {
		handler = middleware[i](handler)
	}
	return handler
}
