# Go 服务生命周期实验

四章共用、仅依赖 Go 1.27.1 标准库的实验项目。入口、并发、下游调用和停机使用同一套所有权约定；不包含数据库或消息系统，不是可直接上线的订单服务。

## 完整验证

需要 Go **1.27.1** 的完整工具链。真实信号进程实验已在 **Linux amd64** 验证；`shutdownlab` 用 `/dev/stdin` 的独立描述符控制测试屏障，不承诺 Windows 兼容。race 构建需要系统已具备 Go 支持的 C 工具链。

```sh
go version
./verify.sh
```

指定已有 Go 工具链时使用 `GO=/path/to/go1.27.1/bin/go ./verify.sh`。若默认构建缓存不可写，把 `GOCACHE` 指向自己的可写目录。项目无外部模块依赖；不要求 Docker、固定端口或外部账户。

脚本执行：

1. 构建普通 `shutdownlab`，放入临时目录
2. 设置 `LIFECYCLE_BINARY`，运行所有普通测试，包括真实 `main` 子进程
3. 构建 race 版子进程，再运行全部 race 测试
4. 运行 vet，保留本次 `evidence/*.log`
5. 删除自己创建的临时可执行文件

构建使用 `-buildvcs=false`，使解压后实验不依赖上层目录的 VCS 元数据。`go test` 使用 `-count=1` 避免复用测试结果，`-p 1` 与 `GOMAXPROCS=2` 限制运行资源；不表示生产建议使用这组容量。

单独运行：

```sh
go test -count=1 -v ./pipeline
go test -count=1 -v ./workers
go test -count=1 -v ./outbound
go test -count=1 -v ./lifecycle
```

最后一条若未设置 `LIFECYCLE_BINARY`，真实 main 测试会明确 **SKIP**。这些跳过不能被报告成真实信号测试通过；完整证据请运行 `verify.sh`。

## 项目地图

- `pipeline`：路径/方法/媒体类型、有界 JSON、领域参数、单点写回，真实回环 HTTP 验证；另有已提交后双写反例
- `workers`：固定 worker 和有限队列；拒绝过载；有限 fan-out、首错取消与 join；panic 清理
- `outbound`：可复用 Client、有限响应体、父预算内退避和限定状态码重试；连接 trace 与未知 POST 结果反例
- `lifecycle`：封住应用入口、HTTP 排空、显式 handler join、后台任务 join、一次性资源关闭；包括不合作任务边界
- `cmd/shutdownlab`：真正的 main，SIGTERM 与 stdin 控制屏障；退出码 0 正常、1 超期、2 启动/服务失败

任务池的接单只发生在内存中。`lab-order` 和演示 `resource_closed` 事件分别代表可控业务替身和显式清理回调，不代表数据库写入、数据库连接或跨进程持久化。

## 关键测试如何避免猜时序

并发测试使用 channel 屏障，计时逻辑使用 `testing/synctest`。网络测试在 synctest bubble 之外使用真实 loopback socket。真实子进程先发出 `handler_started` 与 `job_started`，测试才通过所拥有的进程句柄发送 SIGTERM；在 `listener_closed` 后尝试新连接，分别检查拒绝、工作退出、实际池完成信号、依赖关闭顺序和退出码。

正常信号场景用 `release-http` 与 `release-job` 两个命令分别放开工作。超期场景不放行，观察连接关闭和协作取消。测试的 5–10 秒超时是故障 watchdog；50ms 是被测强制停机策略，均不是“sleep 后假定执行到了某行”。

控制 reader 本身也是实验进程拥有的资源。它打开独立、可被 Close 唤醒的 `/dev/stdin` 描述符，退出前关闭并 join；只打印 stopped 但卡在 reader 清理上，不能通过退出码断言。

## 已验证与未验证

详见 `VERIFICATION.md`。源文件指纹见 `SOURCE-SHA256SUMS`。

HTTP 响应矩阵独立列出准确 body、公开错误码、媒体类型、返回 ID 和输入参数，不以 JSON 语法合法代替响应正确。正常 main 响应必须完整读完且内容正确；强制分支必须观察受控连接中断。启动失败与正常/超期退出都检查实际 Pool.Done 已关闭后才关闭依赖。四个错误实现的修订前后结果见 `REGRESSION.md`。

源码之外没有预打包可执行文件、依赖缓存、密钥、工作区绝对路径或原始运行日志。自己复跑时才会生成 `evidence` 目录。
