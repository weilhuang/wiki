module example.com/lifecyclelab

go 1.27.1
