// shutdownlab is an experiment with stdin barriers, not a production order service.
package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"example.com/lifecyclelab/lifecycle"
	"example.com/lifecyclelab/pipeline"
	"example.com/lifecyclelab/workers"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

type events struct {
	mu      sync.Mutex
	encoder *json.Encoder
}

func (e *events) emit(name string, fields ...string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	event := map[string]string{"event": name}
	for i := 0; i+1 < len(fields); i += 2 {
		event[fields[i]] = fields[i+1]
	}
	_ = e.encoder.Encode(event)
}

type observedListener struct {
	net.Listener
	once sync.Once
	e    *events
}

func (l *observedListener) Close() error {
	err := l.Listener.Close()
	l.once.Do(func() { l.e.emit("listener_closed") })
	return err
}
func main() { os.Exit(run()) }
func run() int {
	addr := flag.String("listen", "127.0.0.1:0", "loopback only for this lab")
	grace := flag.Duration("grace", 3*time.Second, "drain duration")
	flag.Parse()
	e := &events{encoder: json.NewEncoder(os.Stdout)}
	signalCtx, stopSignals := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stopSignals()
	pool := workers.New(1, 1)
	resourceClosed := false
	closeResources := func() error {
		if resourceClosed {
			return errors.New("resource closed twice")
		}
		// Observe actual worker completion, not merely a call to Cancel or Wait.
		select {
		case <-pool.Done():
			e.emit("pool_done")
		default:
			return errors.New("cannot close resources: owned pool still running")
		}
		resourceClosed = true
		e.emit("resource_closed")
		return nil
	}
	listener, err := net.Listen("tcp", *addr)
	if err != nil {
		pool.Cancel()
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if joinErr := pool.Wait(ctx); joinErr != nil {
			e.emit("startup_failed", "error", errors.Join(err, joinErr).Error())
			return 2
		}
		if closeErr := closeResources(); closeErr != nil {
			err = errors.Join(err, closeErr)
		}
		e.emit("startup_failed", "error", err.Error())
		return 2
	}
	control, err := os.Open("/dev/stdin") // Own a pollable descriptor that Close can unblock on Linux.
	if err != nil {
		_ = listener.Close()
		pool.Cancel()
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if joinErr := pool.Wait(ctx); joinErr != nil {
			e.emit("startup_failed", "error", errors.Join(err, joinErr).Error())
			return 2
		}
		if closeErr := closeResources(); closeErr != nil {
			err = errors.Join(err, closeErr)
		}
		e.emit("startup_failed", "error", err.Error())
		return 2
	}
	httpRelease, jobRelease := make(chan struct{}), make(chan struct{})
	var httpOnce, jobOnce sync.Once
	scannerDone := make(chan struct{})
	go func() {
		defer close(scannerDone)
		scanner := bufio.NewScanner(control)
		for scanner.Scan() {
			switch scanner.Text() {
			case "release-http":
				httpOnce.Do(func() { close(httpRelease) })
			case "release-job":
				jobOnce.Do(func() { close(jobRelease) })
			}
		}
	}()
	defer func() { _ = control.Close(); <-scannerDone }()
	gate := lifecycle.NewGate()
	api := pipeline.API{Submit: func(ctx context.Context, order pipeline.Order) (string, error) {
		_, err := pool.Submit(func(ctx context.Context) error {
			e.emit("job_started")
			defer e.emit("job_exited")
			select {
			case <-jobRelease:
				return nil
			case <-ctx.Done():
				return ctx.Err()
			}
		})
		if err != nil {
			return "", pipeline.ErrUnavailable
		}
		e.emit("handler_started")
		defer e.emit("handler_exited")
		select {
		case <-httpRelease:
			return "lab-order", nil
		case <-ctx.Done():
			return "", ctx.Err()
		}
	}}
	server := &http.Server{Handler: gate.Wrap(api), ReadHeaderTimeout: time.Second, IdleTimeout: time.Second}
	served := make(chan error, 1)
	go func() { served <- server.Serve(&observedListener{Listener: listener, e: e}) }()
	e.emit("ready", "address", listener.Addr().String())
	var serveErr error
	serveExited := false
	select {
	case <-signalCtx.Done():
	case serveErr = <-served:
		serveExited = true
		e.emit("serve_failed", "error", fmt.Sprint(serveErr))
	}
	stopSignals() // A second signal restores the default termination behavior.
	// The shutdown contexts must not inherit an already-canceled signal context.
	drain, cancelDrain := context.WithTimeout(context.Background(), *grace)
	defer cancelDrain()
	final, cancelFinal := context.WithTimeout(context.Background(), *grace+time.Second)
	defer cancelFinal()
	stopper := &lifecycle.Stopper{HTTP: server, Jobs: pool, Unready: func() { gate.Seal(); e.emit("unready") }, WaitHandlers: gate.Wait, CloseResources: closeResources}
	err = stopper.Stop(drain, final)
	if !serveExited {
		serveErr = <-served
	}
	if serveErr != nil && !errors.Is(serveErr, http.ErrServerClosed) {
		err = errors.Join(err, serveErr)
	}
	if err != nil {
		e.emit("stopped", "result", "forced", "error", err.Error())
		if serveExited {
			return 2
		}
		return 1
	}
	e.emit("stopped", "result", "graceful")
	return 0
}
