package workers

import (
	"context"
	"errors"
	"reflect"
	"sync/atomic"
	"testing"
	"testing/synctest"
	"time"
)

func TestPoolBoundedQueueAndAbandonedResult(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := New(1, 1)
		started := make(chan struct{})
		release := make(chan struct{})
		first, err := p.Submit(func(context.Context) error { close(started); <-release; return nil })
		if err != nil {
			t.Fatal(err)
		}
		<-started
		// This result is deliberately never received: its producer must still finish.
		if _, err := p.Submit(func(context.Context) error { return nil }); err != nil {
			t.Fatal(err)
		}
		if _, err := p.Submit(func(context.Context) error { return nil }); !errors.Is(err, ErrFull) {
			t.Fatalf("got %v", err)
		}
		p.CloseAdmission()
		p.CloseAdmission()
		if _, err := p.Submit(func(context.Context) error { return nil }); !errors.Is(err, ErrClosed) {
			t.Fatalf("got %v", err)
		}
		close(release)
		if err := <-first; err != nil {
			t.Fatal(err)
		}
		if err := p.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
	})
}
func TestPoolPanicCleanupAndContinuedUse(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := New(1, 2)
		var cleaned atomic.Bool
		first, err := p.Submit(func(context.Context) error { defer cleaned.Store(true); panic("isolated task") })
		if err != nil {
			t.Fatal(err)
		}
		var panicErr *PanicError
		if !errors.As(<-first, &panicErr) || !cleaned.Load() {
			t.Fatal("panic/cleanup contract failed")
		}
		next, err := p.Submit(func(context.Context) error { return nil })
		if err != nil {
			t.Fatal(err)
		}
		if err := <-next; err != nil {
			t.Fatal(err)
		}
		p.CloseAdmission()
		if err := p.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
	})
}
func TestPoolWaitDeadlineDoesNotKillTask(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := New(1, 1)
		started := make(chan struct{})
		exited := make(chan struct{})
		_, err := p.Submit(func(ctx context.Context) error { defer close(exited); close(started); <-ctx.Done(); return ctx.Err() })
		if err != nil {
			t.Fatal(err)
		}
		<-started
		p.CloseAdmission()
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if !errors.Is(p.Wait(ctx), context.DeadlineExceeded) {
			t.Fatal("expected wait timeout")
		}
		select {
		case <-exited:
			t.Fatal("wait unexpectedly canceled task")
		default:
		}
		p.Cancel()
		if err := p.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
		<-exited
	})
}
func TestMapBoundAndOrderedResults(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		var active, max atomic.Int32
		entered := make(chan struct{}, 2)
		release := make(chan struct{})
		done := make(chan struct{})
		var result []int
		var err error
		go func() {
			defer close(done)
			result, err = Map(context.Background(), []int{1, 2, 3, 4, 5}, 2, func(ctx context.Context, x int) (int, error) {
				current := active.Add(1)
				defer active.Add(-1)
				for {
					old := max.Load()
					if current <= old || max.CompareAndSwap(old, current) {
						break
					}
				}
				select {
				case entered <- struct{}{}:
				default:
				}
				<-release
				return x * 2, nil
			})
		}()
		<-entered
		<-entered
		synctest.Wait()
		if active.Load() != 2 {
			t.Fatalf("active=%d", active.Load())
		}
		close(release)
		<-done
		if err != nil || max.Load() != 2 || active.Load() != 0 || !reflect.DeepEqual(result, []int{2, 4, 6, 8, 10}) {
			t.Fatalf("result=%v err=%v max=%d active=%d", result, err, max.Load(), active.Load())
		}
	})
}
func TestMapFirstErrorCancelsAndJoins(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		boom := errors.New("lookup failed")
		slowStarted := make(chan struct{})
		slowExited := make(chan struct{})
		result, err := Map(context.Background(), []int{1, 2, 3}, 2, func(ctx context.Context, x int) (int, error) {
			if x == 1 {
				close(slowStarted)
				defer close(slowExited)
				<-ctx.Done()
				return 0, ctx.Err()
			}
			<-slowStarted
			return 0, boom
		})
		if result != nil || !errors.Is(err, boom) {
			t.Fatalf("result=%v err=%v", result, err)
		}
		select {
		case <-slowExited:
		default:
			t.Fatal("returned before owned worker exit")
		}
	})
}
func TestMapCallerCancelJoins(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		started := make(chan struct{})
		done := make(chan error)
		var exited bool
		go func() {
			_, err := Map(ctx, []int{1}, 1, func(ctx context.Context, x int) (int, error) {
				defer func() { exited = true }()
				close(started)
				<-ctx.Done()
				return 0, ctx.Err()
			})
			done <- err
		}()
		<-started
		cancel()
		if err := <-done; !errors.Is(err, context.Canceled) || !exited {
			t.Fatalf("err=%v exited=%v", err, exited)
		}
	})
}

func TestPoolDoneMeansWorkersExited(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		p := New(1, 1)
		started := make(chan struct{})
		exited := make(chan struct{})
		_, err := p.Submit(func(ctx context.Context) error { close(started); defer close(exited); <-ctx.Done(); return ctx.Err() })
		if err != nil {
			t.Fatal(err)
		}
		<-started
		p.CloseAdmission()
		select {
		case <-p.Done():
			t.Fatal("Done closed with active worker")
		default:
		}
		p.Cancel()
		if err := p.Wait(context.Background()); err != nil {
			t.Fatal(err)
		}
		select {
		case <-exited:
		default:
			t.Fatal("worker defer not complete")
		}
		select {
		case <-p.Done():
		default:
			t.Fatal("Wait returned before Done")
		}
	})
}
