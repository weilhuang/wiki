package workers

import (
	"context"
	"errors"
	"fmt"
	"sync"
)

var ErrFull = errors.New("queue full")
var ErrClosed = errors.New("admission closed")

type Task func(context.Context) error
type PanicError struct{ Value any }

func (p *PanicError) Error() string { return fmt.Sprintf("task panic: %v", p.Value) }
func invoke(ctx context.Context, task Task) (err error) {
	defer func() {
		if value := recover(); value != nil {
			err = &PanicError{Value: value}
		}
	}()
	if err := ctx.Err(); err != nil {
		return err
	}
	return task(ctx)
}

type job struct {
	task   Task
	result chan error
}
type Pool struct {
	mu     sync.Mutex
	closed bool
	jobs   chan job
	ctx    context.Context
	cancel context.CancelFunc
	done   chan struct{}
}

// New owns exactly n worker goroutines and one join goroutine.
func New(n, queue int) *Pool {
	if n < 1 || queue < 1 {
		panic("positive workers and queue required")
	}
	ctx, cancel := context.WithCancel(context.Background())
	p := &Pool{jobs: make(chan job, queue), ctx: ctx, cancel: cancel, done: make(chan struct{})}
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range p.jobs {
				job.result <- invoke(ctx, job.task)
				close(job.result)
			}
		}()
	}
	go func() { wg.Wait(); cancel(); close(p.done) }()
	return p
}

// Submit never starts a goroutine and never waits for queue capacity.
// CloseAdmission and Submit are serialized to prevent send-on-closed-channel.
func (p *Pool) Submit(task Task) (<-chan error, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.closed {
		return nil, ErrClosed
	}
	result := make(chan error, 1)
	select {
	case p.jobs <- job{task, result}:
		return result, nil
	default:
		return nil, ErrFull
	}
}
func (p *Pool) CloseAdmission() {
	p.mu.Lock()
	defer p.mu.Unlock()
	if !p.closed {
		p.closed = true
		close(p.jobs)
	}
}
func (p *Pool) Cancel() { p.CloseAdmission(); p.cancel() }

// Done closes only after all owned workers have finished. Callers cannot close it.
func (p *Pool) Done() <-chan struct{} { return p.done }

func (p *Pool) Wait(ctx context.Context) error {
	select {
	case <-p.done:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// Map is a finite, request-owned fan-out. Failure discards results only after join.
// fn must observe ctx and eventually return; cancellation cannot enforce that.
func Map(ctx context.Context, inputs []int, n int, fn func(context.Context, int) (int, error)) ([]int, error) {
	if n < 1 {
		return nil, errors.New("positive worker limit required")
	}
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	type indexed struct{ index, value int }
	jobs := make(chan indexed, n)
	results := make([]int, len(inputs))
	var wg sync.WaitGroup
	var once sync.Once
	var first error
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				err := invoke(ctx, func(ctx context.Context) error {
					value, err := fn(ctx, j.value)
					if err == nil {
						results[j.index] = value
					}
					return err
				})
				if err != nil {
					once.Do(func() { first = err; cancel() })
				}
			}
		}()
	}
enqueue:
	for i, value := range inputs {
		select {
		case jobs <- indexed{i, value}:
		case <-ctx.Done():
			break enqueue
		}
	}
	close(jobs)
	wg.Wait()
	if first != nil {
		return nil, first
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return results, nil
}
