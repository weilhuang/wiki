#!/bin/sh
set -eu
cd "$(dirname "$0")"
GO=${GO:-go}
export GOTOOLCHAIN=local GOMAXPROCS=${GOMAXPROCS:-2}
export GOFLAGS="${GOFLAGS:-} -buildvcs=false"
mkdir -p evidence
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT INT TERM
"$GO" version | tee evidence/version.log
"$GO" build -p 1 -o "$work/shutdownlab" ./cmd/shutdownlab
export LIFECYCLE_BINARY="$work/shutdownlab"
status=0
"$GO" test -p 1 -count=1 -timeout=60s -v ./... > evidence/tests.log 2>&1 || status=$?
cat evidence/tests.log
[ "$status" -eq 0 ] || exit "$status"
"$GO" build -race -p 1 -o "$work/shutdownlab-race" ./cmd/shutdownlab
export LIFECYCLE_BINARY="$work/shutdownlab-race"
"$GO" test -race -p 1 -count=1 -timeout=60s ./... > evidence/race.log 2>&1
cat evidence/race.log
"$GO" vet -p 1 ./... > evidence/vet.log 2>&1
cat evidence/vet.log
