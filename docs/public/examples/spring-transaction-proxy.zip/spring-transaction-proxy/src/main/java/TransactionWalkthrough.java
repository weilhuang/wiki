import java.sql.Connection;
import java.util.Arrays;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.UnexpectedRollbackException;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

/** Run this main class. Every printed PASS follows an exception and/or database assertion. */
public class TransactionWalkthrough {
    @Configuration
    @EnableTransactionManagement
    public static class Config {
        @Bean(destroyMethod = "shutdown")
        public org.springframework.jdbc.datasource.embedded.EmbeddedDatabase dataSource() {
            return new EmbeddedDatabaseBuilder()
                    .generateUniqueName(true)
                    .setType(EmbeddedDatabaseType.H2)
                    .build();
        }

        @Bean public JdbcTemplate jdbc(DataSource ds) { return new JdbcTemplate(ds); }
        @Bean public PlatformTransactionManager transactionManager(DataSource ds) {
            return new DataSourceTransactionManager(ds);
        }
        @Bean public Example example(JdbcTemplate jdbc) { return new Example(jdbc); }
        @Bean public Inner inner(JdbcTemplate jdbc) { return new Inner(jdbc); }
        @Bean public Outer outer(JdbcTemplate jdbc, Inner inner) { return new Outer(jdbc, inner); }
        @Bean public Programmatic programmatic(JdbcTemplate jdbc, PlatformTransactionManager manager) {
            return new Programmatic(jdbc, new TransactionTemplate(manager));
        }
    }

    public static class Example {
        private final JdbcTemplate jdbc;
        public Example(JdbcTemplate jdbc) { this.jdbc = jdbc; }

        // An unannotated entry point. The next call uses this, not the Spring proxy.
        public void record() { recordAndFail(); }

        @Transactional
        public void recordAndFail() {
            jdbc.update("insert into events(label) values (?)", "created");
            throw new IllegalStateException("写入后失败");
        }

        // There is an outer transaction, but no inner interceptor sees the exception.
        @Transactional
        public void catchSelf() {
            try { recordAndFail(); } catch (IllegalStateException ignored) { }
        }

        @Transactional
        public void outerSelfRequiresNew() {
            jdbc.update("insert into events(label) values (?)", "outer");
            selfAudit();
            throw new IllegalStateException("外层失败");
        }

        // This annotation is deliberately bypassed by outerSelfRequiresNew.
        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void selfAudit() {
            jdbc.update("insert into events(label) values (?)", "self-audit");
        }

        @Transactional
        public void checkedDefault() throws CheckedFailure {
            jdbc.update("insert into events(label) values (?)", "checked");
            throw new CheckedFailure();
        }

        @Transactional(rollbackFor = CheckedFailure.class)
        public void checkedRollback() throws CheckedFailure {
            jdbc.update("insert into events(label) values (?)", "checked");
            throw new CheckedFailure();
        }

        @Transactional
        public void verifyConnection() {
            require(TransactionSynchronizationManager.isActualTransactionActive(), "no active transaction");
            Connection[] first = new Connection[1];
            jdbc.execute((ConnectionCallback<Void>) connection -> {
                require(!connection.getAutoCommit(), "autoCommit should be false inside transaction");
                first[0] = DataSourceUtils.getTargetConnection(connection);
                return null;
            });
            jdbc.execute((ConnectionCallback<Void>) connection -> {
                require(DataSourceUtils.getTargetConnection(connection) == first[0],
                        "JdbcTemplate did not reuse the bound connection");
                return null;
            });
        }
    }

    public static class CheckedFailure extends Exception { }

    public static class Inner {
        private final JdbcTemplate jdbc;
        public Inner(JdbcTemplate jdbc) { this.jdbc = jdbc; }

        @Transactional
        public void fail() {
            jdbc.update("insert into events(label) values (?)", "inner");
            throw new IllegalStateException("内部失败");
        }

        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void audit() {
            jdbc.update("insert into events(label) values (?)", "audit");
        }
    }

    public static class Outer {
        private final JdbcTemplate jdbc;
        private final Inner inner;
        public Outer(JdbcTemplate jdbc, Inner inner) { this.jdbc = jdbc; this.inner = inner; }

        @Transactional
        public void catchInner() {
            jdbc.update("insert into events(label) values (?)", "outer");
            try { inner.fail(); } catch (IllegalStateException ignored) { }
        }

        @Transactional
        public void failAfterAudit() {
            jdbc.update("insert into events(label) values (?)", "outer");
            inner.audit();
            throw new IllegalStateException("外部失败");
        }
    }

    public static class Programmatic {
        private final JdbcTemplate jdbc;
        private final TransactionTemplate tx;
        public Programmatic(JdbcTemplate jdbc, TransactionTemplate tx) { this.jdbc = jdbc; this.tx = tx; }

        public void record() {
            tx.executeWithoutResult(status -> {
                jdbc.update("insert into events(label) values (?)", "created");
                throw new IllegalStateException("写入后失败");
            });
        }
    }

    @FunctionalInterface interface Action { void run() throws Exception; }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void verify(
            JdbcTemplate jdbc, String name, Action action,
            Class<? extends Throwable> expectedException, String... expectedLabels) {
        jdbc.update("delete from events");
        Throwable thrown = null;
        try { action.run(); } catch (Throwable failure) { thrown = failure; }
        if (expectedException == null) {
            require(thrown == null, name + ": unexpected exception " + thrown);
        } else {
            require(expectedException.isInstance(thrown), name + ": unexpected exception " + thrown);
        }
        List<String> labels = jdbc.queryForList("select label from events order by label", String.class);
        require(labels.equals(Arrays.asList(expectedLabels)), name + ": rows were " + labels);
        System.out.println("PASS " + name + " -> " + labels);
    }

    public static void main(String[] args) {
        try (var context = new AnnotationConfigApplicationContext(Config.class)) {
            JdbcTemplate jdbc = context.getBean(JdbcTemplate.class);
            jdbc.execute("create table events(label varchar(80))");
            Example example = context.getBean(Example.class);
            Outer outer = context.getBean(Outer.class);
            require(AopUtils.isAopProxy(example), "Example must be a Spring proxy");
            boolean autoCommit = Boolean.TRUE.equals(jdbc.execute(
                    (ConnectionCallback<Boolean>) Connection::getAutoCommit));
            require(autoCommit, "This experiment assumes autoCommit outside a transaction");
            verify(jdbc, "direct", example::recordAndFail, IllegalStateException.class);
            verify(jdbc, "self", example::record, IllegalStateException.class, "created");
            verify(jdbc, "template", context.getBean(Programmatic.class)::record, IllegalStateException.class);
            verify(jdbc, "required-catch", outer::catchInner, UnexpectedRollbackException.class);
            verify(jdbc, "requires-new", outer::failAfterAudit, IllegalStateException.class, "audit");
            verify(jdbc, "self-catch", example::catchSelf, null, "created");
            verify(jdbc, "self-requires-new", example::outerSelfRequiresNew, IllegalStateException.class);
            verify(jdbc, "checked-default", example::checkedDefault, CheckedFailure.class, "checked");
            verify(jdbc, "checked-rollback", example::checkedRollback, CheckedFailure.class);
            verify(jdbc, "connection-bound", example::verifyConnection, null);
            require(!TransactionSynchronizationManager.isActualTransactionActive(), "transaction leaked");
            System.out.println("ALL 10 SCENARIOS PASSED");
        }
    }
}
