# Spring 事务调用链：可运行实验

需要完整 JDK 21 和 Gradle 8.10.2。首次执行需要联网下载依赖。固定使用 Spring Framework 6.2.19 与 H2 2.3.232，不依赖 Spring Boot，也不需要 Docker。

```sh
java -version
gradle --version
gradle run
```

入口为 `src/main/java/TransactionWalkthrough.java`。程序创建独立内存数据库，每个场景开始前清空 `events`。它使用显式断言检查异常类型和最终行内容，不需要启用 Java `-ea`。

预期最后输出 `ALL 10 SCENARIOS PASSED`。中间还会出现 Spring/H2 的启动关闭日志。任一断言失败都会导致执行失败，不以启动成功代替验证。

| 场景 | 预期保留的 label |
| --- | --- |
| direct | 无 |
| self | created |
| template | 无 |
| required-catch | 无 |
| requires-new | audit |
| self-catch | created |
| self-requires-new | 无 |
| checked-default | checked |
| checked-rollback | 无 |
| connection-bound | 无，同时检查事务内关闭自动提交且复用连接 |

该实验验证代理、传播与 JDBC 资源使用，不验证 MySQL/PostgreSQL 的锁、隔离、死锁恢复或线上连接池容量。`events` 没有跨事务争用，不能据此推断 `REQUIRES_NEW` 不会等锁。

## 验证范围

这份源码已在 JDK 21、Gradle 8.10.2、Spring 6.2.19、H2 2.3.232 下完成编译与十个场景运行。依赖已有缓存时，`gradle --offline run` 也可运行。没有在其他数据库或分布式部署上验证这些结果。
