#!/usr/bin/env python3
"""Mutate only producers, then require the existing checks to reject each broken program.
Uses the caller's installed Gradle/JDK and prepared cache; never edits the original project.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=Path('negative-control-results'))
args = parser.parse_args()
output = args.output.resolve(); output.mkdir(parents=True, exist_ok=True)
project = Path(__file__).resolve().parents[1]
gradle = os.environ.get('GRADLE_BIN') or shutil.which('gradle')
if not gradle:
    raise SystemExit('Gradle 8.10.2 must be installed; use PATH or GRADLE_BIN')

cases = [
    ('missing-success-body', 'HttpLab.java', 'http',
     [('response.getWriter().write("{\\"id\\":\\"" + id + "\\"}");',
       'response.getWriter().write("BROKEN_SUCCESS_BODY");')],
     'created response: complete JSON required'),
    ('wrong-error-contract', 'HttpLab.java', 'http',
     [(f'Map.of("code", "{code}")', 'Map.of("code", "success")')
      for code in ('invalid_input', 'order_rejected', 'capacity_unavailable')],
     'error code contract: invalid_input'),
    ('missing-consumer-destroy', 'LifecycleLab.java', 'lifecycle',
     [('@Bean(initMethod = "init", destroyMethod = "close") Consumer consumer()',
       '@Bean(initMethod = "init", destroyMethod = "") Consumer consumer()')],
     'event exactly once: consumer:close'),
]
results=[]
for name, filename, scope, changes, expected in cases:
    with tempfile.TemporaryDirectory(prefix='spring-negative-') as temp:
        target=Path(temp)/'project'
        shutil.copytree(project, target, ignore=shutil.ignore_patterns('.gradle','build','negative-control-results','__pycache__'))
        source=target/'src/main/java/lab'/filename
        text=source.read_text()
        for old, new in changes:
            if text.count(old) != 1:
                raise AssertionError(f'{name}: expected exactly one producer mutation target: {old!r}')
            text=text.replace(old,new)
        source.write_text(text)
        command=[gradle,'--offline','--no-daemon','run',f'--args={scope}']
        run=subprocess.run(command,cwd=target,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        (output/(name+'.log')).write_text(run.stdout)
        rejected=run.returncode != 0 and expected in run.stdout and 'ALL REQUESTED LABS PASSED' not in run.stdout
        result={'name':name,'exitCode':run.returncode,'expectedAssertion':expected,'rejectedForExpectedReason':rejected,
                'mutatedFile':filename,'mutatedFileSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                'command':['gradle',*command[1:]]}
        results.append(result)
        print(json.dumps(result,ensure_ascii=False),flush=True)
        if not rejected:
            (output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
            raise AssertionError(f'{name}: negative control was not rejected for its intended reason')
(output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
print('ALL 3 NEGATIVE CONTROLS REJECTED')
