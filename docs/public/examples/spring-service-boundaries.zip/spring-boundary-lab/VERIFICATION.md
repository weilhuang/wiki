# 验证记录 R2

日期：2026-10-02。状态：verified，限本文件声明范围；独立复审与网站视觉验收另行进行。

## 最终源码实际执行

- JDK：Temurin 21.0.12.1+1（完整 JDK）；Gradle 8.10.2
- 单 worker，Gradle 与 JavaExec 堆各 256 MB
- 命令：`gradle --offline --no-daemon run --args=all dependencies --configuration runtimeClasspath`（外部 90s 上限）
- Exit code：0；`BUILD SUCCESSFUL in 14s`；`ALL REQUESTED LABS PASSED: all`
- 版本：Boot 3.5.16 / Spring 6.2.19 / Tomcat 10.1.55 / Servlet 6.0 / HikariCP 6.3.3 / H2 2.3.232 / Hibernate Validator 8.0.3.Final
- Jackson databind/core 2.21.4、annotations 2.21，来自固定 Boot BOM
- 独立 Gradle 用户目录与准备好的 Maven Central 依赖缓存；本轮离线执行

R2 修复了旧版测试的误报通过：成功只检查状态/行数、错误 code 仅打印、缺失事件的 indexOf(-1) 参与顺序比较。修复后重新编译并完整执行，不复用旧版通过结论。

## 检查范围

1. 四组生命周期合同：托管/手动清理、prototype 调用方逐个清理一次、指定启动失败根因与双路径清理、构造器环
2. 生命周期检查器额外拒绝缺失、重复、反序三种事件日志
3. 五组池场景：宽事务 1s、宽事务 3s、窄事务、跨线程副作用、预算过期后的 JDBC 访问
4. 池范围场景实际采集 active/idle/pending/total；指定 holder 与 waiter 的真实栈；事务内 unwrap 的底层连接身份；归还后复用身份与最终池值
5. 八条真实回环 HTTP：成功、DTO 校验失败、非法 JSON、业务回滚、连接耗尽、指定晚到部分响应、新请求排空拒绝、已接纳请求完成
6. 正常/排空成功都检查完整严格 JSON、media type、DTO schema、UUID 与唯一新增行对应、行内 sku/quantity；错误 code 和每场景进入计数/完整 trace 全部断言；失败使用完整数据库行快照
7. 只有 LATE 场景允许明确指定的不完整 JSON，同时独立验证新增行；context 结束后明确检查池关闭

## 真实源码变异

命令：`python3 scripts/verify-negative-controls.py`，脚本 exit 0，三个受测 Java 程序分别 exit 1：

- missing-success-body：`created response: complete JSON required`
- wrong-error-contract：`error code contract: invalid_input`
- missing-consumer-destroy：`event exactly once: consumer:close`

脚本只改响应/生命周期配置，保留断言。每次都要求命中指定断言，编译失败、其他异常或超时不能替代预期拒绝。JSON/日志详见 `negative-control-output.txt`。本轮不是声称对所有可想象变体做了穷举。

## 源码绑定

`SOURCE_SHA256SUMS` 记录七个 Java/Gradle 程序输入。对其 UTF-8 原始内容计算 SHA-256：

`581bf9d1ce10a6f282b67b28d067e858a36249e344f1ad1b53fa019b4ca5d9d5`

负向验证辅助源码 `scripts/verify-negative-controls.py` SHA-256：

`f68fb6e69147f20f11a9c1f677770446975c45c260004487ac921e6d85814ff3`

源文件在上述成功与变异验证结束后未再修改。文章、说明和日志不参与 Java 程序输入摘要；ZIP 自身摘要由发布清单记录，避免自指。

## NOT_RUN / 不可外推

未验证 MySQL/PostgreSQL 隔离/锁/取消、真实下游网络超时、嵌套 REQUIRES_NEW 耗尽实验、异步 MVC、TLS/代理/HTTP2/浏览器断连、独立 JVM SIGTERM 或编排平台摘流、身份/库存/支付/幂等/消息交接、负载吞吐。1s/3s 对照只证明延长允许等待不会释放持有者，不是超时耗尽时长比较。应用接纳开关只在本例受控顺序下验证，不推广为通用原子接纳协议。
