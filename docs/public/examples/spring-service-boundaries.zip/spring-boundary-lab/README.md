# Spring 服务边界实验

这是四章共用的独立实验项目：对象所有权、Servlet MVC 完成链、连接预算、订单服务评审。已有的事务代理十场景项目独立保留，不被本项目替换。

## 环境

- 完整 JDK 21；本轮使用 Temurin 21.0.12.1+1
- Gradle 8.10.2（没有捆绑 Gradle Wrapper 或工具链）
- Spring Boot 3.5.16 / Spring Framework 6.2.19
- Tomcat 10.1.55 / Servlet 6.0
- HikariCP 6.3.3 / H2 2.3.232 / Hibernate Validator 8.0.3.Final

版本由固定 Boot BOM 与直接依赖约束解析，本轮解析记录见 `verification-output.txt`。首次运行需要从 Maven Central 获取依赖；有完整依赖缓存后可离线运行。

## 运行

```sh
java -version
gradle --version
gradle run --args=all
# 分别运行，仍由同一项目编译
gradle run --args=lifecycle
gradle run --args=pool
gradle run --args=http
# 缓存已准备好时
gradle --offline --no-daemon run --args=all
```

入口 `lab.AllLabs`。所有检查显式抛出 AssertionError，不依赖 `-ea`。四个 Java 文件构成完整源码，不需要将文章片段拼接。

## 场景与故障注入

- LifecycleLab：托管/手动对象身份与顺序；prototype 的调用方清理；启动失败时工厂局部资源清理与已登记 singleton 清理；构造器依赖环
- PoolLab：一个连接和两个工作线程；latch 固定持有/等待顺序；1s 与 3s 借连接等待预算反例；窄事务对照；跨线程独立提交；1s 事务预算到期后下一次 JDBC 访问
- HttpLab：绑定 `127.0.0.1` 的随机端口，JDK HttpClient 发出真实请求；合法/无效/非法 JSON、插入后业务拒绝、借连接耗尽、提交后不完整响应、应用排空中新旧请求

`FAIL`、`LATE`、`SLOW` sku 和 `X-Lab-Case` 都是实验注入/关联开关，不是生产商品规则、鉴权方案或公共 API。SLOW 停在本地事务之前，晚到失败发生在数据库提交与 `flushBuffer()` 之后。池耗尽由测试持有唯一连接制造，不需要真把数据库压垮。

每个 latch/Future 有有界结束条件；finally 释放闸门，try-with-resources 关闭线程池与连接池，HttpLab 最后关闭 context。H2 是进程内内存库，进程退出后数据清除。没有 Docker、外部数据库、第三方 HTTP 调用或文件持久化服务。

## 如何读证据

不要只看 PASS。HTTP 测试严格检查完整 JSON、媒体类型、唯一 id 与独立查询行的对应、sku/quantity、精确错误 code；所有进入计数及事件链的存在/次数/顺序/缺失都参与断言。非法输入、回滚与拒绝还比较完整行快照。池证据采集命名 holder/waiter 的真实栈、实际池数值与解包后的物理连接身份。晚到失败的正确观测是 HTTP 201 + 不完整 JSON + 数据增加，不是 500 + 回滚。业务拒绝被异常解析后，afterCompletion 的异常参数为空也不代表业务成功。

`VERIFICATION.md` 记录实际命令、结果、源码绑定和范围。构建输出未装入 ZIP；`verification-output.txt` 是文本证据，不是二进制依赖。

## 没有验证的范围

H2 不证明 MySQL 锁/隔离/取消；latch 不证明真实远端取消；应用接纳开关不证明独立 JVM SIGTERM 或 Kubernetes 摘流；没有异步 Servlet 分派、反向代理、TLS、库存、支付、认证、幂等、消息或多实例一致性测试。增加这些能力时需要另外定义合同与证据。

## 反向验证测试是否会误报通过

可选工具为已有 Python 3，不需要安装第三方 Python 包。准备好 JDK、Gradle 和依赖缓存后执行：

```sh
python3 scripts/verify-negative-controls.py
```

脚本在临时项目副本分别把成功响应体写坏、把三种错误响应 code 改成 success、禁用消费者销毁回调。只修改生产者，不修改对应断言。每个变体必须以非零退出，并含预期断言；三项全被正确拒绝时，脚本自身退出 0。原项目不被修改。GRADLE_BIN 可指定已安装的 Gradle 8.10.2 可执行文件。

生命周期正例内部还将缺失、重复、顺序颠倒的日志交给同一检查器，三种都必须拒绝。`negative-control-output.txt` 保存本轮实际源码变异结论，完整日志由运行脚本产生在输出目录。
