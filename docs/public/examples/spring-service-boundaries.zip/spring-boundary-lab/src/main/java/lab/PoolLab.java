package lab;

import com.zaxxer.hikari.*;
import java.sql.Connection;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionTimedOutException;
import org.springframework.transaction.support.*;

public final class PoolLab {
    static HikariDataSource pool(String name, int max) {
        var config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=false");
        config.setMaximumPoolSize(max); config.setMinimumIdle(0);
        config.setConnectionTimeout(1000); config.setPoolName(name);
        return new HikariDataSource(config);
    }
    static void await(CountDownLatch latch) {
        try { AllLabs.check(latch.await(5, TimeUnit.SECONDS), "latch deadline"); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException(e); }
    }
    static void eventually(java.util.function.BooleanSupplier predicate) {
        long end = System.nanoTime() + Duration.ofSeconds(3).toNanos();
        while (!predicate.getAsBoolean() && System.nanoTime() < end) Thread.onSpinWait();
        AllLabs.check(predicate.getAsBoolean(), "observation deadline");
    }
    static void run() throws Exception {
        longRange(true, 1000); longRange(true, 3000); longRange(false, 1000); crossThread(); timeout();
    }
    record PoolSnapshot(int active, int idle, int pending, int total) { }
    static PoolSnapshot snapshot(HikariDataSource pool) {
        HikariPoolMXBean mx = pool.getHikariPoolMXBean();
        return new PoolSnapshot(mx.getActiveConnections(), mx.getIdleConnections(),
                mx.getThreadsAwaitingConnection(), mx.getTotalConnections());
    }
    record ConnectionObservation(String thread, String h2Id, int identity, Connection physical) { }
    static void observeConnection(JdbcTemplate jdbc, String role, Map<String, ConnectionObservation> observed) {
        jdbc.execute((org.springframework.jdbc.core.ConnectionCallback<Void>) c -> {
            Connection physical = c.unwrap(org.h2.jdbc.JdbcConnection.class);
            String h2Id = physical.toString().split(":", 2)[0];
            observed.put(role, new ConnectionObservation(Thread.currentThread().getName(), h2Id,
                    System.identityHashCode(physical), physical));
            return null;
        });
    }
    static String stackEvidence(Thread thread, String className, String method) {
        AllLabs.check(thread != null, "named thread must be recorded");
        StackTraceElement[] stack = thread.getStackTrace();
        AllLabs.check(Arrays.stream(stack).anyMatch(f -> f.getClassName().equals(className) && f.getMethodName().equals(method)),
                "expected stack frame for " + thread.getName() + ": " + className + "." + method);
        return thread.getName() + " state=" + thread.getState() + " stack=" + Arrays.toString(stack);
    }
    static void longRange(boolean wide, long waitBudget) throws Exception {
        String label = "range_" + wide + "_" + waitBudget;
        try (var pool = pool(label, 1); var workers = Executors.newFixedThreadPool(2)) {
            pool.setConnectionTimeout(waitBudget);
            var jdbc = new JdbcTemplate(pool);
            jdbc.execute("create table events(label varchar(30))");
            var tx = new TransactionTemplate(new DataSourceTransactionManager(pool));
            var remoteEntered = new CountDownLatch(1);
            var remoteRelease = new CountDownLatch(1);
            var holderThread = new AtomicReference<Thread>();
            var waiterThread = new AtomicReference<Thread>();
            Map<String, ConnectionObservation> connections = new ConcurrentHashMap<>();
            Runnable remote = () -> { remoteEntered.countDown(); await(remoteRelease); };
            Future<?> holder = workers.submit(() -> {
                Thread.currentThread().setName(label + "-holder"); holderThread.set(Thread.currentThread());
                if (wide) tx.executeWithoutResult(s -> {
                    jdbc.update("insert into events values ('holder')");
                    observeConnection(jdbc, "holder", connections); remote.run();
                });
                else {
                    remote.run();
                    tx.executeWithoutResult(s -> {
                        jdbc.update("insert into events values ('holder')"); observeConnection(jdbc, "holder", connections);
                    });
                }
            });
            try {
                await(remoteEntered);
                Future<?> contender = workers.submit(() -> {
                    Thread.currentThread().setName(label + "-waiter"); waiterThread.set(Thread.currentThread());
                    tx.executeWithoutResult(s -> {
                        jdbc.update("insert into events values ('contender')"); observeConnection(jdbc, "contender", connections);
                    });
                });
                if (wide) {
                    eventually(() -> pool.getHikariPoolMXBean().getThreadsAwaitingConnection() == 1);
                    PoolSnapshot actual = snapshot(pool);
                    AllLabs.check(actual.equals(new PoolSnapshot(1, 0, 1, 1)), "actual held pool values: " + actual);
                    String holderStack = stackEvidence(holderThread.get(), "java.util.concurrent.CountDownLatch", "await");
                    String waiterStack = stackEvidence(waiterThread.get(), "com.zaxxer.hikari.util.ConcurrentBag", "borrow");
                    AllLabs.check(connections.containsKey("holder") && !connections.containsKey("contender"), "only holder obtained a connection");
                    ConnectionObservation held = connections.get("holder");
                    System.out.println("OBSERVE wide connectionTimeout=" + waitBudget + " " + actual
                            + " heldBy=" + held.thread() + " connection=" + held.h2Id() + " identity=" + held.identity());
                    System.out.println("STACK holder " + holderStack);
                    System.out.println("STACK waiter " + waiterStack);
                    AllLabs.check(!contender.isDone(), "waiting remains while owner holds connection");
                } else {
                    contender.get(3, TimeUnit.SECONDS);
                    PoolSnapshot actual = snapshot(pool);
                    AllLabs.check(actual.equals(new PoolSnapshot(0, 1, 0, 1)), "actual narrow pool values: " + actual);
                    AllLabs.check(!connections.containsKey("holder") && connections.containsKey("contender"), "remote wait has not borrowed a connection");
                    System.out.println("OBSERVE narrow contender finished while remote is blocked " + actual);
                    System.out.println("STACK holder " + stackEvidence(holderThread.get(), "java.util.concurrent.CountDownLatch", "await"));
                }
                remoteRelease.countDown();
                holder.get(3, TimeUnit.SECONDS); contender.get(3, TimeUnit.SECONDS);
                AllLabs.check(jdbc.queryForObject("select count(*) from events", Integer.class) == 2, "both writes complete");
                ConnectionObservation h = connections.get("holder"), c = connections.get("contender");
                AllLabs.check(h != null && c != null && h.physical() == c.physical(), "single physical connection reused after return");
                PoolSnapshot after = snapshot(pool);
                AllLabs.check(after.equals(new PoolSnapshot(0, 1, 0, 1)), "all connections returned: " + after);
                System.out.println("PASS pool-range " + (wide ? "wide" : "narrow") + " connectionTimeout=" + waitBudget
                        + " holder=" + h.h2Id() + " contender=" + c.h2Id() + " samePhysical=true final=" + after);
            } finally { remoteRelease.countDown(); }
        }
    }
    static void crossThread() throws Exception {
        try (var pool = pool("threads", 2); var worker = Executors.newSingleThreadExecutor()) {
            var jdbc = new JdbcTemplate(pool);
            jdbc.execute("create table events(label varchar(30))");
            var tx = new TransactionTemplate(new DataSourceTransactionManager(pool));
            var ids = new ConcurrentHashMap<String, String>();
            try {
                tx.executeWithoutResult(s -> {
                    AllLabs.check(TransactionSynchronizationManager.isActualTransactionActive(), "parent tx");
                    jdbc.execute((org.springframework.jdbc.core.ConnectionCallback<Void>) c -> {
                        ids.put("parent", c.unwrap(org.h2.jdbc.JdbcConnection.class).toString()); return null;
                    });
                    jdbc.update("insert into events values ('parent')");
                    try {
                        worker.submit(() -> {
                            AllLabs.check(!TransactionSynchronizationManager.isActualTransactionActive(), "child has no inherited tx");
                            jdbc.execute((org.springframework.jdbc.core.ConnectionCallback<Void>) c -> {
                                ids.put("child", c.unwrap(org.h2.jdbc.JdbcConnection.class).toString()); return null;
                            });
                            jdbc.update("insert into events values ('child')");
                        }).get(3, TimeUnit.SECONDS);
                    } catch (Exception e) { throw new RuntimeException(e); }
                    throw new IllegalStateException("rollback parent");
                });
            } catch (IllegalStateException expected) { }
            AllLabs.check(jdbc.queryForList("select label from events", String.class).equals(List.of("child")), "child committed independently");
            AllLabs.check(!ids.get("parent").equals(ids.get("child")), "distinct H2 connections");
            System.out.println("PASS pool-cross-thread " + ids + " rows=[child]");
        }
    }
    static void timeout() throws Exception {
        try (var pool = pool("timeout", 1); var timer = Executors.newSingleThreadScheduledExecutor()) {
            var jdbc = new JdbcTemplate(pool);
            jdbc.execute("create table events(label varchar(30))");
            var tx = new TransactionTemplate(new DataSourceTransactionManager(pool)); tx.setTimeout(1);
            var timerFired = new CountDownLatch(1);
            var codeContinued = new AtomicBoolean();
            try {
                tx.executeWithoutResult(s -> {
                    jdbc.update("insert into events values ('before')");
                    timer.schedule(timerFired::countDown, 1500, TimeUnit.MILLISECONDS);
                    await(timerFired); codeContinued.set(true);
                    jdbc.update("insert into events values ('after')");
                });
                throw new AssertionError("expired transaction must be detected by next JDBC access");
            } catch (TransactionTimedOutException expected) { }
            AllLabs.check(codeContinued.get(), "transaction timeout did not interrupt Java wait");
            AllLabs.check(jdbc.queryForObject("select count(*) from events", Integer.class) == 0, "rollback on detected timeout");
            System.out.println("PASS pool-timeout code-continued=true rows=0");
        }
    }
}
