package lab;

import com.zaxxer.hikari.HikariDataSource;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.core.JsonParser;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.annotation.*;
import org.springframework.core.Ordered;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.config.annotation.*;

public final class HttpLab {
    @SpringBootConfiguration(proxyBeanMethods = false)
    @EnableAutoConfiguration
    static class App {
        @Bean State state() { return new State(); }
        @Bean(destroyMethod = "close") HikariDataSource dataSource() { return PoolLab.pool("http_lab", 1); }
        @Bean OrderService orders(JdbcTemplate jdbc, HikariDataSource pool) {
            return new OrderService(jdbc, new TransactionTemplate(new DataSourceTransactionManager(pool)));
        }
        @Bean Controller controller(State state, OrderService orders) { return new Controller(state, orders); }
        @Bean Errors errors() { return new Errors(); }
        @Bean GateFilter gate(State state) { return new GateFilter(state); }
        @Bean CommittedResolver committedResolver(State state) { return new CommittedResolver(state); }
        @Bean WebMvcConfigurer observations() {
            return new WebMvcConfigurer() {
                public void addInterceptors(InterceptorRegistry registry) {
                    registry.addInterceptor(new HandlerInterceptor() {
                        public boolean preHandle(HttpServletRequest r, HttpServletResponse s, Object h) {
                            trace(r).add("interceptor:pre"); return true;
                        }
                        public void postHandle(HttpServletRequest r, HttpServletResponse s, Object h, ModelAndView m) {
                            trace(r).add("interceptor:post");
                        }
                        public void afterCompletion(HttpServletRequest r, HttpServletResponse s, Object h, Exception e) {
                            trace(r).add("interceptor:after:" + (e == null ? "null" : e.getClass().getSimpleName()));
                        }
                    });
                }
            };
        }
    }
    static final class State {
        final AtomicBoolean accepting = new AtomicBoolean(true);
        final AtomicInteger handlerEntries = new AtomicInteger();
        final ConcurrentMap<String, List<String>> traces = new ConcurrentHashMap<>();
        final AtomicBoolean sawCommittedFailure = new AtomicBoolean();
        final CountDownLatch slowEntered = new CountDownLatch(1), slowRelease = new CountDownLatch(1);
    }
    @SuppressWarnings("unchecked") static List<String> trace(HttpServletRequest request) {
        return (List<String>) request.getAttribute("lab.trace");
    }
    static final class GateFilter extends OncePerRequestFilter implements Ordered {
        final State state;
        GateFilter(State state) { this.state = state; }
        public int getOrder() { return Ordered.HIGHEST_PRECEDENCE; }
        protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
                throws ServletException, IOException {
            List<String> log = new ArrayList<>(); req.setAttribute("lab.trace", log); log.add("filter:enter");
            try {
                if (!state.accepting.get()) {
                    res.setStatus(503); res.setContentType("application/json");
                    res.getWriter().write("{\"code\":\"draining\"}"); return;
                }
                chain.doFilter(req, res);
            } finally {
                log.add("filter:exit:" + res.getStatus() + ":committed=" + res.isCommitted());
                state.traces.put(req.getHeader("X-Lab-Case"), List.copyOf(log));
            }
        }
    }
    public record CreateOrder(@NotBlank String sku, @Min(1) int quantity) { }
    static final class OrderService {
        final JdbcTemplate jdbc; final TransactionTemplate tx;
        OrderService(JdbcTemplate jdbc, TransactionTemplate tx) { this.jdbc = jdbc; this.tx = tx; }
        String create(CreateOrder command) {
            return tx.execute(status -> {
                String id = UUID.randomUUID().toString();
                jdbc.update("insert into orders(id, sku, quantity) values (?, ?, ?)", id, command.sku(), command.quantity());
                if (command.sku().equals("FAIL")) throw new DomainFailure();
                return id;
            });
        }
    }
    static final class DomainFailure extends RuntimeException { }
    static final class CommittedFailure extends RuntimeException { }
    @RestController
    static final class Controller {
        final State state; final OrderService orders;
        Controller(State state, OrderService orders) { this.state = state; this.orders = orders; }
        @PostMapping(path = "/orders", consumes = "application/json")
        public void create(@Valid @RequestBody CreateOrder command, HttpServletRequest request, HttpServletResponse response)
                throws IOException {
            state.handlerEntries.incrementAndGet(); trace(request).add("controller:enter");
            if (command.sku().equals("SLOW")) { state.slowEntered.countDown(); PoolLab.await(state.slowRelease); }
            String id = orders.create(command); trace(request).add("service:committed");
            response.setStatus(201); response.setContentType("application/json");
            if (command.sku().equals("LATE")) {
                response.getWriter().write("{\"id\":"); response.flushBuffer();
                throw new CommittedFailure();
            }
            response.getWriter().write("{\"id\":\"" + id + "\"}");
        }
    }
    @RestControllerAdvice
    static final class Errors {
        @ExceptionHandler({MethodArgumentNotValidException.class, HttpMessageNotReadableException.class})
        ResponseEntity<Map<String, String>> invalid(Exception e) { return ResponseEntity.badRequest().body(Map.of("code", "invalid_input")); }
        @ExceptionHandler(DomainFailure.class)
        ResponseEntity<Map<String, String>> conflict() { return ResponseEntity.status(409).body(Map.of("code", "order_rejected")); }
        @ExceptionHandler(CannotCreateTransactionException.class)
        ResponseEntity<Map<String, String>> unavailable() { return ResponseEntity.status(503).body(Map.of("code", "capacity_unavailable")); }
    }
    static final class CommittedResolver implements HandlerExceptionResolver, Ordered {
        final State state;
        CommittedResolver(State state) { this.state = state; }
        public int getOrder() { return Ordered.HIGHEST_PRECEDENCE; }
        public ModelAndView resolveException(HttpServletRequest req, HttpServletResponse res, Object h, Exception ex) {
            if (!(ex instanceof CommittedFailure)) return null;
            AllLabs.check(res.isCommitted(), "late fault must occur after response commit");
            state.sawCommittedFailure.set(true); trace(req).add("resolver:already-committed");
            // Lab deliberately leaves the partial response intact. A resolver cannot replace sent bytes.
            return new ModelAndView();
        }
    }
    static HttpRequest request(URI base, String label, String json) {
        return HttpRequest.newBuilder(base.resolve("/orders")).timeout(Duration.ofSeconds(5))
            .header("Content-Type", "application/json").header("X-Lab-Case", label)
            .POST(HttpRequest.BodyPublishers.ofString(json)).build();
    }
    static String json(String sku, int quantity) { return "{\"sku\":\"" + sku + "\",\"quantity\":" + quantity + "}"; }
    static int rows(JdbcTemplate jdbc) { return jdbc.queryForObject("select count(*) from orders", Integer.class); }
    record StoredOrder(String id, String sku, int quantity) { }
    static List<StoredOrder> snapshotRows(JdbcTemplate jdbc) {
        return jdbc.query("select id, sku, quantity from orders order by id",
                (rs, n) -> new StoredOrder(rs.getString("id"), rs.getString("sku"), rs.getInt("quantity")));
    }
    static Set<String> ids(JdbcTemplate jdbc) {
        return Set.copyOf(jdbc.queryForList("select id from orders", String.class));
    }
    static JsonNode jsonResponse(HttpResponse<String> response, String contract) {
        String type = response.headers().firstValue("Content-Type").orElse("");
        AllLabs.check(type.split(";", 2)[0].equalsIgnoreCase("application/json"), contract + ": Content-Type");
        try {
            JsonNode body = new ObjectMapper().enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
                    .enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION).readTree(response.body());
            AllLabs.check(body != null && body.isObject(), contract + ": JSON object required");
            return body;
        } catch (IOException invalid) {
            throw new AssertionError(contract + ": complete JSON required", invalid);
        }
    }
    static void assertCreated(HttpResponse<String> response, JdbcTemplate jdbc,
            Set<String> beforeIds, String expectedSku, int expectedQuantity) {
        AllLabs.check(response.statusCode() == 201, "created status");
        JsonNode body = jsonResponse(response, "created response");
        AllLabs.check(body.size() == 1 && body.has("id") && body.get("id").isTextual(), "created DTO shape");
        String id = body.get("id").asText();
        try { AllLabs.check(UUID.fromString(id).toString().equals(id), "canonical UUID"); }
        catch (IllegalArgumentException malformed) { throw new AssertionError("created UUID", malformed); }
        Set<String> afterIds = ids(jdbc);
        Set<String> added = new HashSet<>(afterIds); added.removeAll(beforeIds);
        AllLabs.check(afterIds.size() == beforeIds.size() + 1 && afterIds.containsAll(beforeIds)
                && added.equals(Set.of(id)), "response id must match the one independently persisted row");
        List<CreateOrder> persisted = jdbc.query("select sku, quantity from orders where id = ?",
                (rs, n) -> new CreateOrder(rs.getString("sku"), rs.getInt("quantity")), id);
        AllLabs.check(persisted.equals(List.of(new CreateOrder(expectedSku, expectedQuantity))), "persisted DTO fields");
    }
    static void assertError(HttpResponse<String> response, int status, String expectedCode) {
        AllLabs.check(response.statusCode() == status, "error status " + expectedCode);
        JsonNode body = jsonResponse(response, "error response " + expectedCode);
        AllLabs.check(body.size() == 1 && body.has("code") && body.get("code").isTextual()
                && body.get("code").asText().equals(expectedCode), "error code contract: " + expectedCode);
    }

    static void result(State state, String label, int status, String body, int before, int after, int calls) {
        PoolLab.eventually(() -> state.traces.containsKey(label));
        int expectedCalls = switch (label) {
            case "invalid", "malformed", "drain-new" -> 0;
            default -> 1;
        };
        AllLabs.check(calls == expectedCalls, label + ": exact handler delta");
        List<String> expectedTrace = switch (label) {
            case "success", "drain-inflight" -> List.of("filter:enter", "interceptor:pre", "controller:enter",
                    "service:committed", "interceptor:post", "interceptor:after:null", "filter:exit:201:committed=false");
            case "invalid", "malformed" -> List.of("filter:enter", "interceptor:pre", "interceptor:after:null", "filter:exit:400:committed=true");
            case "business-failure" -> List.of("filter:enter", "interceptor:pre", "controller:enter", "interceptor:after:null", "filter:exit:409:committed=true");
            case "pool-exhausted" -> List.of("filter:enter", "interceptor:pre", "controller:enter", "interceptor:after:null", "filter:exit:503:committed=true");
            case "late-response" -> List.of("filter:enter", "interceptor:pre", "controller:enter", "service:committed",
                    "resolver:already-committed", "interceptor:after:null", "filter:exit:201:committed=true");
            case "drain-new" -> List.of("filter:enter", "filter:exit:503:committed=false");
            default -> throw new AssertionError("unknown HTTP case: " + label);
        };
        AllLabs.check(state.traces.get(label).equals(expectedTrace), label + ": exact trace presence/count/order/absence " + state.traces.get(label));

        System.out.println("HTTP " + label + " status=" + status + " rows=" + before + "->" + after +
                " handlerDelta=" + calls + " body=" + body + " trace=" + state.traces.get(label));
    }
    static void run() throws Exception {
        var app = new SpringApplication(App.class);
        app.setDefaultProperties(Map.of("server.address", "127.0.0.1", "server.port", "0", "spring.main.banner-mode", "off",
            "logging.level.root", "WARN", "server.shutdown", "graceful", "spring.lifecycle.timeout-per-shutdown-phase", "5s"));
        var context = (ServletWebServerApplicationContext) app.run();
        var pool = context.getBean(HikariDataSource.class);
        var state = context.getBean(State.class);
        try (var client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build()) {
            var jdbc = context.getBean(JdbcTemplate.class);
            jdbc.execute("create table orders(id varchar(36) primary key, sku varchar(40), quantity int)");
            URI base = URI.create("http://127.0.0.1:" + context.getWebServer().getPort());
            int before = rows(jdbc), entered = state.handlerEntries.get();
            Set<String> beforeIds = ids(jdbc);
            var good = client.send(request(base, "success", json("BOOK", 1)), HttpResponse.BodyHandlers.ofString());
            assertCreated(good, jdbc, beforeIds, "BOOK", 1);
            result(state, "success", good.statusCode(), good.body(), before, rows(jdbc), state.handlerEntries.get() - entered);

            before = rows(jdbc); entered = state.handlerEntries.get();
            List<StoredOrder> beforeState = snapshotRows(jdbc);
            var invalid = client.send(request(base, "invalid", json("", 0)), HttpResponse.BodyHandlers.ofString());
            assertError(invalid, 400, "invalid_input");
            AllLabs.check(snapshotRows(jdbc).equals(beforeState) && state.handlerEntries.get() == entered, "validation before handler, unchanged rows");
            result(state, "invalid", invalid.statusCode(), invalid.body(), before, rows(jdbc), state.handlerEntries.get() - entered);
            var malformed = client.send(request(base, "malformed", "{"), HttpResponse.BodyHandlers.ofString());
            assertError(malformed, 400, "invalid_input");
            AllLabs.check(snapshotRows(jdbc).equals(beforeState) && state.handlerEntries.get() == entered, "parse before handler, unchanged rows");
            result(state, "malformed", malformed.statusCode(), malformed.body(), before, rows(jdbc), state.handlerEntries.get() - entered);

            before = rows(jdbc); entered = state.handlerEntries.get(); beforeState = snapshotRows(jdbc);
            var fail = client.send(request(base, "business-failure", json("FAIL", 1)), HttpResponse.BodyHandlers.ofString());
            assertError(fail, 409, "order_rejected");
            AllLabs.check(snapshotRows(jdbc).equals(beforeState), "business rollback, unchanged rows");
            result(state, "business-failure", fail.statusCode(), fail.body(), before, rows(jdbc), state.handlerEntries.get() - entered);
            AllLabs.check(state.traces.get("business-failure").contains("interceptor:after:null"), "resolved exception is not passed as afterCompletion ex");

            before = rows(jdbc); entered = state.handlerEntries.get(); beforeState = snapshotRows(jdbc);
            HttpResponse<String> exhausted;
            try (var held = pool.getConnection()) {
                exhausted = client.send(request(base, "pool-exhausted", json("BOOK", 1)), HttpResponse.BodyHandlers.ofString());
                assertError(exhausted, 503, "capacity_unavailable");
            }
            AllLabs.check(snapshotRows(jdbc).equals(beforeState), "borrow failure before SQL, unchanged rows");
            result(state, "pool-exhausted", exhausted.statusCode(), exhausted.body(), before, rows(jdbc), state.handlerEntries.get() - entered);

            before = rows(jdbc); entered = state.handlerEntries.get(); beforeIds = ids(jdbc);
            var late = client.send(request(base, "late-response", json("LATE", 1)), HttpResponse.BodyHandlers.ofString());
            AllLabs.check(late.statusCode() == 201 && late.body().equals("{\"id\":") && rows(jdbc) == before + 1 && state.sawCommittedFailure.get(), "partial response after database commit");
            AllLabs.check(late.headers().firstValue("Content-Type").orElse("").split(";", 2)[0].equals("application/json"), "late Content-Type");
            Set<String> lateIds = new HashSet<>(ids(jdbc)); lateIds.removeAll(beforeIds);
            AllLabs.check(lateIds.size() == 1, "late response has exactly one new persisted row");
            CreateOrder lateRow = jdbc.queryForObject("select sku, quantity from orders where id = ?",
                (rs, n) -> new CreateOrder(rs.getString("sku"), rs.getInt("quantity")), lateIds.iterator().next());
            AllLabs.check(lateRow.equals(new CreateOrder("LATE", 1)), "late persisted DTO");
            result(state, "late-response", late.statusCode(), late.body(), before, rows(jdbc), state.handlerEntries.get() - entered);

            before = rows(jdbc); entered = state.handlerEntries.get(); beforeIds = ids(jdbc);
            var inflight = client.sendAsync(request(base, "drain-inflight", json("SLOW", 1)), HttpResponse.BodyHandlers.ofString());
            PoolLab.await(state.slowEntered);
            int afterAdmitted = state.handlerEntries.get(); beforeState = snapshotRows(jdbc);
            state.accepting.set(false);
            var rejected = client.send(request(base, "drain-new", json("BOOK", 1)), HttpResponse.BodyHandlers.ofString());
            assertError(rejected, 503, "draining");
            AllLabs.check(state.handlerEntries.get() == entered + 1 && snapshotRows(jdbc).equals(beforeState), "new request rejected before MVC, unchanged rows");
            result(state, "drain-new", rejected.statusCode(), rejected.body(), before, rows(jdbc), state.handlerEntries.get() - afterAdmitted);
            state.slowRelease.countDown();
            var finished = inflight.get(5, TimeUnit.SECONDS);
            assertCreated(finished, jdbc, beforeIds, "SLOW", 1);
            result(state, "drain-inflight", finished.statusCode(), finished.body(), before, rows(jdbc), state.handlerEntries.get() - entered);
        } finally { state.slowRelease.countDown(); context.close(); }
        AllLabs.check(pool.isClosed(), "context owns pool close");
        System.out.println("PASS http-and-review poolClosed=true");
    }
}
