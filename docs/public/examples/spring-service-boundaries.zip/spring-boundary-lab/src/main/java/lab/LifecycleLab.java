package lab;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;

public final class LifecycleLab {
    static final List<String> events = new ArrayList<>();
    public static final class Resource implements AutoCloseable {
        final String name;
        final AtomicBoolean closed = new AtomicBoolean();
        boolean ready;
        int closes;
        Resource(String name) { this.name = name; events.add(name + ":construct"); }
        public void init() { ready = true; events.add(name + ":init"); }
        public void use() {
            if (!ready || closed.get()) throw new IllegalStateException("not ready");
            events.add(name + ":use");
        }
        public void close() {
            if (closed.compareAndSet(false, true)) { closes++; events.add(name + ":close"); }
        }
    }
    public static final class Consumer {
        Resource resource;
        Consumer() { events.add("consumer:construct"); }
        @Autowired void inject(Resource resource) { this.resource = resource; events.add("consumer:inject"); }
        public void init() { events.add("consumer:init"); }
        public void close() { events.add("consumer:close"); }
    }
    @Configuration(proxyBeanMethods = false)
    static class Good {
        @Bean(initMethod = "init", destroyMethod = "close") Resource resource() { return new Resource("managed"); }
        @Bean(initMethod = "init", destroyMethod = "close") Consumer consumer() { return new Consumer(); }
    }
    @Configuration(proxyBeanMethods = false)
    static class Prototype {
        @Bean(initMethod = "init", destroyMethod = "close") @Scope("prototype")
        Resource resource() { return new Resource("prototype"); }
    }
    static Resource failedFactoryResource;
    @Configuration(proxyBeanMethods = false)
    static class Failure {
        @Bean(initMethod = "init", destroyMethod = "close") Resource stable() { return new Resource("stable"); }
        @Bean @DependsOn("stable") String broken() {
            Resource local = new Resource("factory-local");
            failedFactoryResource = local;
            try {
                local.init();
                throw new IllegalArgumentException("configuration rejected");
            } catch (RuntimeException failure) {
                local.close();
                throw failure;
            }
        }
    }
    static class A { A(B b) {} }
    static class B { B(A a) {} }
    static void onceBefore(List<String> log, String before, String after) {
        AllLabs.check(Collections.frequency(log, before) == 1, "event exactly once: " + before);
        AllLabs.check(Collections.frequency(log, after) == 1, "event exactly once: " + after);
        AllLabs.check(log.indexOf(before) < log.indexOf(after), "event order: " + before + " before " + after);
    }
    static void verifyManagedTrace(List<String> log) {
        List<String> expected = List.of("managed:construct", "managed:init", "managed:use", "managed:close",
            "consumer:construct", "consumer:inject", "consumer:init", "consumer:close", "manual:construct", "manual:close");
        AllLabs.check(log.size() == expected.size(), "managed trace exact event count");
        for (String event : expected) AllLabs.check(Collections.frequency(log, event) == 1, "event exactly once: " + event);
        onceBefore(log, "managed:construct", "managed:init");
        onceBefore(log, "managed:init", "consumer:inject");
        onceBefore(log, "consumer:construct", "consumer:inject");
        onceBefore(log, "consumer:inject", "consumer:init");
        onceBefore(log, "consumer:init", "managed:use");
        onceBefore(log, "managed:use", "consumer:close");
        onceBefore(log, "consumer:close", "managed:close");
        onceBefore(log, "manual:construct", "manual:close");
    }
    static void negativeTraceChecks(List<String> baseline) {
        List<String> missing = new ArrayList<>(baseline); missing.remove("consumer:close");
        List<String> duplicate = new ArrayList<>(baseline); duplicate.add("consumer:close");
        List<String> reversed = new ArrayList<>(baseline);
        Collections.swap(reversed, reversed.indexOf("consumer:close"), reversed.indexOf("managed:close"));
        for (List<String> bad : List.of(missing, duplicate, reversed)) {
            boolean rejected = false;
            try { verifyManagedTrace(bad); } catch (AssertionError expected) { rejected = true; }
            AllLabs.check(rejected, "negative lifecycle trace must be rejected");
        }
        System.out.println("PASS lifecycle-trace-negative-controls missing/duplicate/reordered rejected");
    }
    static void run() {
        events.clear();
        var ctx = new AnnotationConfigApplicationContext(Good.class);
        Resource managed = ctx.getBean(Resource.class);
        managed.use();
        AllLabs.check(ctx.getBean(Consumer.class).resource == managed, "injected identity");
        onceBefore(events, "managed:init", "consumer:inject");
        onceBefore(events, "consumer:inject", "consumer:init");
        Resource manual = new Resource("manual");
        try { manual.use(); throw new AssertionError("manual new must not initialize itself"); }
        catch (IllegalStateException expected) { }
        ctx.close(); ctx.close();
        AllLabs.check(managed.closes == 1 && manual.closes == 0, "container owns only managed resource");
        onceBefore(events, "consumer:close", "managed:close");
        manual.close(); manual.close();
        AllLabs.check(manual.closes == 1, "application close is idempotent");
        verifyManagedTrace(events);
        negativeTraceChecks(events);
        System.out.println("PASS lifecycle-managed-manual " + events);

        events.clear();
        var prototypes = new AnnotationConfigApplicationContext(Prototype.class);
        Resource p1 = prototypes.getBean(Resource.class), p2 = prototypes.getBean(Resource.class);
        prototypes.close();
        AllLabs.check(p1 != p2 && p1.ready && p2.ready && p1.closes == 0 && p2.closes == 0, "prototype caller owns cleanup");
        p1.close(); p2.close();
        AllLabs.check(p1.closes == 1 && p2.closes == 1, "prototype caller closes each exactly once");
        System.out.println("PASS lifecycle-prototype " + events);

        events.clear();
        var failed = new AnnotationConfigApplicationContext();
        failed.register(Failure.class);
        try { failed.refresh(); throw new AssertionError("startup should fail"); }
        catch (BeanCreationException expected) {
            Throwable cause = expected;
            while (cause.getCause() != null) cause = cause.getCause();
            AllLabs.check(cause instanceof IllegalArgumentException && "configuration rejected".equals(cause.getMessage()),
                    "intended startup failure reason");
        }
        finally { failed.close(); }
        AllLabs.check(Collections.frequency(events, "stable:close") == 1 && failedFactoryResource != null
                && failedFactoryResource.closes == 1, "both ownership paths cleaned exactly once");
        onceBefore(events, "factory-local:init", "factory-local:close");
        onceBefore(events, "factory-local:close", "stable:close");
        System.out.println("PASS lifecycle-startup-failure " + events);

        var cycle = new AnnotationConfigApplicationContext();
        cycle.register(A.class, B.class);
        try { cycle.refresh(); throw new AssertionError("constructor cycle should fail"); }
        catch (BeanCreationException expected) {
            Throwable root = expected;
            while (root.getCause() != null) root = root.getCause();
            AllLabs.check(root instanceof org.springframework.beans.factory.BeanCurrentlyInCreationException,
                    "cycle root cause: " + root);
            System.out.println("PASS lifecycle-constructor-cycle " + root.getClass().getSimpleName());
        } finally { cycle.close(); }
    }
}
