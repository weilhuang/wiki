package lab;

public final class AllLabs {
    public static void main(String[] args) throws Exception {
        String scope = args.length == 0 ? "all" : args[0];
        if (scope.equals("all") || scope.equals("lifecycle")) LifecycleLab.run();
        if (scope.equals("all") || scope.equals("pool")) PoolLab.run();
        if (scope.equals("all") || scope.equals("http")) HttpLab.run();
        if (!java.util.Set.of("all", "lifecycle", "pool", "http").contains(scope))
            throw new IllegalArgumentException("all | lifecycle | pool | http");
        System.out.println("ALL REQUESTED LABS PASSED: " + scope);
    }
    static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
