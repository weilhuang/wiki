// Package contextlab demonstrates request-lifetime policies, not a database.
package contextlab

import (
	"context"
	"time"
)

// CreateWithin is an intentionally strict cancellation-at-return policy.
// It cannot undo a side effect and is not a generic transaction wrapper.
// A downstream error keeps priority over a simultaneous context error.
func CreateWithin(parent context.Context, budget time.Duration,
	create func(context.Context) (string, error),
) (string, error) {
	ctx, cancel := context.WithTimeout(parent, budget)
	defer cancel()
	if err := ctx.Err(); err != nil {
		return "", err
	}
	id, err := create(ctx)
	if err != nil {
		return "", err
	}
	if err := ctx.Err(); err != nil {
		return "", err
	}
	return id, nil
}

// Count returns an unbuffered stream and a lifecycle completion signal.
// Cancel the context and receive from exited when finished consuming.
// Cancellation can race with a ready receiver; it does not promise zero
// additional values after cancellation.
func Count(ctx context.Context) (<-chan int, <-chan struct{}) {
	out := make(chan int)
	exited := make(chan struct{})
	go func() {
		defer close(exited)
		defer close(out)
		for n := 0; ; n++ {
			select {
			case <-ctx.Done():
				return
			case out <- n:
			}
		}
	}()
	return out, exited
}
