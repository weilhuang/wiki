package contextlab

import (
	"context"
	"errors"
	"testing"
	"testing/synctest"
	"time"
)

func TestParentCanceledBeforeCall(t *testing.T) {
	parent, cancel := context.WithCancel(context.Background())
	cancel()
	calls := 0
	id, err := CreateWithin(parent, time.Minute, func(context.Context) (string, error) {
		calls++
		return "order-1", nil
	})
	if id != "" || !errors.Is(err, context.Canceled) || calls != 0 {
		t.Fatalf("id=%q err=%v calls=%d", id, err, calls)
	}
}

func TestParentCanceledDuringCall(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		parent, cancel := context.WithCancel(context.Background())
		defer cancel()
		entered := make(chan struct{})
		exited := make(chan struct{})
		result := make(chan error, 1)
		go func() {
			_, err := CreateWithin(parent, time.Minute, func(ctx context.Context) (string, error) {
				defer close(exited)
				close(entered)
				<-ctx.Done()
				return "", ctx.Err()
			})
			result <- err
		}()
		<-entered
		cancel()
		if err := <-result; !errors.Is(err, context.Canceled) {
			t.Fatalf("err=%v", err)
		}
		<-exited
	})
}

func TestSideEffectBeforeCancellation(t *testing.T) {
	parent, cancel := context.WithCancel(context.Background())
	defer cancel()
	saved := 0
	id, err := CreateWithin(parent, time.Minute, func(context.Context) (string, error) {
		saved++
		cancel()
		return "order-1", nil
	})
	if id != "" || !errors.Is(err, context.Canceled) || saved != 1 {
		t.Fatalf("id=%q err=%v saved=%d", id, err, saved)
	}
}

func TestParentCanceledAfterSuccessfulReturn(t *testing.T) {
	parent, cancel := context.WithCancel(context.Background())
	defer cancel()
	saved := 0
	id, err := CreateWithin(parent, time.Minute, func(context.Context) (string, error) {
		saved++
		return "order-1", nil
	})
	cancel()
	if id != "order-1" || err != nil || saved != 1 || parent.Err() != context.Canceled {
		t.Fatalf("id=%q err=%v saved=%d parent=%v", id, err, saved, parent.Err())
	}
}

func TestTimeoutUsesFakeTime(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		start := time.Now()
		_, err := CreateWithin(context.Background(), 5*time.Second,
			func(ctx context.Context) (string, error) {
				<-ctx.Done()
				return "", ctx.Err()
			})
		if !errors.Is(err, context.DeadlineExceeded) || time.Since(start) != 5*time.Second {
			t.Fatalf("err=%v elapsed=%v", err, time.Since(start))
		}
	})
}

func TestEarlierParentDeadlineWins(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		parent, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		start := time.Now()
		_, err := CreateWithin(parent, time.Hour, func(ctx context.Context) (string, error) {
			parentDeadline, _ := parent.Deadline()
			childDeadline, _ := ctx.Deadline()
			if !childDeadline.Equal(parentDeadline) {
				t.Fatalf("parent=%v child=%v", parentDeadline, childDeadline)
			}
			<-ctx.Done()
			return "", ctx.Err()
		})
		if !errors.Is(err, context.DeadlineExceeded) || time.Since(start) != 2*time.Second {
			t.Fatalf("err=%v elapsed=%v", err, time.Since(start))
		}
	})
}

func TestChildCancellationDoesNotCancelParentOrSibling(t *testing.T) {
	parent, cancelParent := context.WithCancel(context.Background())
	defer cancelParent()
	child, cancelChild := context.WithCancel(parent)
	defer cancelChild()
	sibling, cancelSibling := context.WithCancel(parent)
	defer cancelSibling()
	grandchild, cancelGrandchild := context.WithCancel(child)
	defer cancelGrandchild()
	cancelChild()
	if child.Err() != context.Canceled || grandchild.Err() != context.Canceled ||
		parent.Err() != nil || sibling.Err() != nil {
		t.Fatalf("parent=%v child=%v sibling=%v grandchild=%v",
			parent.Err(), child.Err(), sibling.Err(), grandchild.Err())
	}
}

func TestParentCancellationReachesAllChildren(t *testing.T) {
	parent, cancelParent := context.WithCancel(context.Background())
	defer cancelParent()
	child, cancelChild := context.WithCancel(parent)
	defer cancelChild()
	sibling, cancelSibling := context.WithCancel(parent)
	defer cancelSibling()
	cancelParent()
	if child.Err() != context.Canceled || sibling.Err() != context.Canceled {
		t.Fatalf("child=%v sibling=%v", child.Err(), sibling.Err())
	}
}

func TestBackgroundLosesParent(t *testing.T) {
	type key struct{}
	parent, cancelParent := context.WithTimeout(
		context.WithValue(context.Background(), key{}, "trace-1"), time.Minute)
	defer cancelParent()
	lost, cancelLost := context.WithCancel(context.Background())
	defer cancelLost()
	cancelParent()
	_, deadline := lost.Deadline()
	if parent.Err() != context.Canceled || lost.Err() != nil || deadline || lost.Value(key{}) != nil {
		t.Fatalf("parent=%v lost=%v deadline=%v value=%v",
			parent.Err(), lost.Err(), deadline, lost.Value(key{}))
	}
}

func TestWithoutCancelKeepsOnlyValues(t *testing.T) {
	type key struct{}
	parent, cancelParent := context.WithTimeout(
		context.WithValue(context.Background(), key{}, "trace-1"), time.Minute)
	defer cancelParent()
	detached := context.WithoutCancel(parent)
	cancelParent()
	_, deadline := detached.Deadline()
	if detached.Done() != nil || detached.Err() != nil || context.Cause(detached) != nil ||
		deadline || detached.Value(key{}) != "trace-1" {
		t.Fatalf("done=%v err=%v cause=%v deadline=%v value=%v",
			detached.Done(), detached.Err(), context.Cause(detached), deadline, detached.Value(key{}))
	}
}

func TestCancelCauseFirstCancellationWins(t *testing.T) {
	parentCause := errors.New("request abandoned")
	childCause := errors.New("local stop")
	for _, parentFirst := range []bool{true, false} {
		name := "child-first"
		if parentFirst {
			name = "parent-first"
		}
		t.Run(name, func(t *testing.T) {
			parent, stopParent := context.WithCancelCause(context.Background())
			defer stopParent(nil)
			child, stopChild := context.WithCancelCause(parent)
			defer stopChild(nil)
			want := childCause
			if parentFirst {
				stopParent(parentCause)
				stopChild(childCause)
				want = parentCause
			} else {
				stopChild(childCause)
				stopParent(parentCause)
			}
			if child.Err() != context.Canceled || context.Cause(child) != want ||
				context.Cause(parent) != parentCause {
				t.Fatalf("err=%v child cause=%v parent cause=%v",
					child.Err(), context.Cause(child), context.Cause(parent))
			}
		})
	}
}

func TestTimeoutCauseAndManualCancelDiffer(t *testing.T) {
	cause := errors.New("inventory budget expired")
	t.Run("deadline", func(t *testing.T) {
		synctest.Test(t, func(t *testing.T) {
			ctx, cancel := context.WithTimeoutCause(context.Background(), time.Second, cause)
			defer cancel()
			<-ctx.Done()
			if ctx.Err() != context.DeadlineExceeded || context.Cause(ctx) != cause {
				t.Fatalf("err=%v cause=%v", ctx.Err(), context.Cause(ctx))
			}
		})
	})
	t.Run("manual-cancel", func(t *testing.T) {
		ctx, cancel := context.WithTimeoutCause(context.Background(), time.Hour, cause)
		defer cancel()
		cancel()
		if ctx.Err() != context.Canceled || context.Cause(ctx) != context.Canceled {
			t.Fatalf("err=%v cause=%v", ctx.Err(), context.Cause(ctx))
		}
	})
}

func TestSuccessfulReturnReleasesChild(t *testing.T) {
	parent, cancelParent := context.WithCancel(context.Background())
	defer cancelParent()
	var captured context.Context
	_, err := CreateWithin(parent, time.Hour, func(ctx context.Context) (string, error) {
		captured = ctx
		return "order-1", nil
	})
	if err != nil || captured.Err() != context.Canceled || parent.Err() != nil {
		t.Fatalf("err=%v child=%v parent=%v", err, captured.Err(), parent.Err())
	}
}

func TestDownstreamErrorKeepsPriority(t *testing.T) {
	parent, cancel := context.WithCancel(context.Background())
	defer cancel()
	businessErr := errors.New("inventory rejected")
	_, err := CreateWithin(parent, time.Minute, func(context.Context) (string, error) {
		cancel()
		return "", businessErr
	})
	if !errors.Is(err, businessErr) {
		t.Fatalf("err=%v", err)
	}
}

func TestCancelDoesNotForceNonCooperativeWorkerToExit(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		entered := make(chan struct{})
		release := make(chan struct{})
		exited := make(chan struct{})
		go func() {
			defer close(exited)
			close(entered)
			<-release // Deliberately ignores ctx.
		}()
		<-entered
		cancel()
		synctest.Wait()
		select {
		case <-exited:
			t.Fatal("non-cooperative worker exited without release")
		default:
		}
		if ctx.Err() != context.Canceled {
			t.Fatalf("err=%v", ctx.Err())
		}
		close(release) // The test owns and cleans up this worker.
		<-exited
	})
}

func TestBlockedSenderExitsOnCancellation(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		out, exited := Count(ctx)
		synctest.Wait() // No receiver: the producer is blocked in select.
		cancel()
		<-exited
		if _, ok := <-out; ok {
			t.Fatal("output channel is still open")
		}
	})
}
