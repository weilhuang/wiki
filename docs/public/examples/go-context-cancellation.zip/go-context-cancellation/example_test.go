package contextlab_test

import (
	"context"
	"errors"
	"fmt"
	"time"

	"example.com/contextlab"
)

func Example_withCancelCause() {
	cause := errors.New("caller stopped waiting")
	ctx, cancel := context.WithCancelCause(context.Background())
	defer cancel(nil)
	cancel(cause)
	fmt.Println(ctx.Err())
	fmt.Println(context.Cause(ctx))
	// Output:
	// context canceled
	// caller stopped waiting
}

func ExampleCreateWithin() {
	parent, cancel := context.WithCancel(context.Background())
	defer cancel()
	saved := 0
	id, err := contextlab.CreateWithin(parent, time.Minute,
		func(ctx context.Context) (string, error) {
			saved++
			cancel()
			return "order-1", nil
		})
	fmt.Printf("id=%q err=%v saved=%d\n", id, err, saved)
	// Output:
	// id="" err=context canceled saved=1
}

func ExampleCount() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	out, exited := contextlab.Count(ctx)
	fmt.Println(<-out)
	cancel()
	<-exited
	// Output:
	// 0
}
