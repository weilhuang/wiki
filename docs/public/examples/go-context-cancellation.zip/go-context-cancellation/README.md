# Go context：请求取消与已完成的副作用

配套文章的独立最小实验。固定 Go 1.27.1，只有标准库，没有服务、Docker、数据库驱动或第三方依赖。

## 运行

```sh
go version
go run ./cmd/demo
go test -count=1 -v ./...
go test -race -count=1 ./...
go vet ./...
```

演示输出：

```text
id="" err=context canceled saved=1
```

`-race` 需要 Go 支持的系统和 C 工具链。测试总超时可由 `go test -timeout=30s` 限定，用于发现死锁，不作为行为正确性的时间判据。

## 文件与阅读顺序

- `contextlab.go`：同步包装函数 `CreateWithin` 与可以取消发送的 `Count`
- `cmd/demo/main.go`：副作用完成、父 context 取消、包装函数返回取消错误的完整调用方
- `contextlab_test.go`：16 个顶层测试，另有 4 个子测试，精确安排先后顺序
- `example_test.go`：3 个带输出断言的完整调用例子

用 `-run TestParentCanceledDuringCall` 等测试名称可以单独复查场景。所有子 goroutine 都有明确退出条件；没有 `time.Sleep`，没有按墙钟毫秒数断言。deadline 测试在 `testing/synctest` 隔离环境的虚拟时间内等待，5 秒预算不需要真的等待 5 秒。

## 每个测试说明什么

| 测试 | 可观察结果 |
| --- | --- |
| ParentCanceledBeforeCall | 已取消的父 context 不启动下游 |
| ParentCanceledDuringCall | 等下游进入后再取消；下游观察 Done 并退出 |
| SideEffectBeforeCancellation | 下游已经改了内存；后置检查返回取消；副作用仍在 |
| ParentCanceledAfterSuccessfulReturn | 后来的取消不改变已经返回的成功和副作用 |
| TimeoutUsesFakeTime | 虚拟时间推进到子 context 的 5 秒期限 |
| EarlierParentDeadlineWins | 父 2 秒预算不会被子 1 小时预算延长 |
| ChildCancellationDoesNotCancelParentOrSibling | 取消向下到孙节点，不向上或横向传播 |
| ParentCancellationReachesAllChildren | 父取消到达两个子节点 |
| BackgroundLosesParent | 重新使用 Background 丢失父取消、期限和 Value |
| WithoutCancelKeepsOnlyValues | 保留 Value；取消、期限和 Cause 不再继承 |
| CancelCauseFirstCancellationWins | 父先取消与子先取消得到不同 Cause |
| TimeoutCauseAndManualCancelDiffer | 自然到期用自定义 cause，手动 cancel 用 Canceled |
| SuccessfulReturnReleasesChild | defer cancel 取消子 context，不取消父 context |
| DownstreamErrorKeepsPriority | 同时取消时保留下游已有错误 |
| CancelDoesNotForceNonCooperativeWorkerToExit | cancel 后 worker 仍活着；测试释放它并确认退出 |
| BlockedSenderExitsOnCancellation | 无人接收时，Count 仍能经取消分支退出 |

## 实验边界

`saved` 是单个函数中的内存计数，刻意不用数据库。它只能证明 context 不会自动恢复已经做完的 Go 操作，不能证明 SQL 提交、隔离、回滚、锁或驱动取消行为。文章的 `database/sql` 部分来自 Go 1.27.1 API 与源码阅读，不属于本项目的数据库集成测试。

`CreateWithin` 展示的是一种严格的“下游成功返回时若已经取消，则向调用方报告取消”的应用策略。它保留下游已有错误。这个策略会隐藏下游刚返回的成功 ID，因此不应原样当作所有写接口的模板。生产写接口需要记录业务结果，明确已提交成功如何返回、未知结果如何查询和重试。

`Count` 中 `select` 没有取消优先级。如果接收者与取消同时就绪，仍可能发送一个值；测试验证的是没有接收者时可以退出。`exited` 是最后一段清理代码执行完毕的信号，接收它用于汇合；它不保证运行时已经回收所有 goroutine 内部结构。
