package main

import (
	"context"
	"fmt"
	"time"

	"example.com/contextlab"
)

func main() {
	parent, cancel := context.WithCancel(context.Background())
	defer cancel()
	saved := 0
	id, err := contextlab.CreateWithin(parent, time.Minute,
		func(ctx context.Context) (string, error) {
			saved++ // An in-memory side effect, not a database commit.
			cancel()
			return "order-1", nil
		})
	fmt.Printf("id=%q err=%v saved=%d\n", id, err, saved)
}
