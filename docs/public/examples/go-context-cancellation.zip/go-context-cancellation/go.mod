module example.com/contextlab

go 1.27.1
